
import { UserProfile, Monster, Stats, Buff, Skill, ClassData, Title, Pet, PetTier, ElementType, Equipment, CharacterRank } from '../types';
import { BOSS_LORES, RANK_THRESHOLDS } from '../constants';
import { GoogleGenAI, Type } from "@google/genai";

export const generateMonster = (floor: number): Monster => {
  const isBoss = floor % 10 === 0;
  const isMiniBoss = !isBoss && floor % 5 === 0;
  const multiplier = isBoss ? 15 : (isMiniBoss ? 6 : 2);
  const name = isBoss ? `Soberano do Andar ${floor}` : (isMiniBoss ? `Guardião do Andar ${floor}` : `Criatura do Andar ${floor}`);

  return {
    name,
    level: floor,
    type: isBoss ? 'Boss' : (isMiniBoss ? 'Mini-Boss' : 'Normal'),
    hp: Math.floor(80 * Math.pow(1.15, floor) * multiplier),
    maxHp: Math.floor(80 * Math.pow(1.15, floor) * multiplier),
    damage: Math.floor(8 * Math.pow(1.1, floor) * (multiplier * 0.6)),
    magicDamage: Math.floor(6 * Math.pow(1.1, floor) * (multiplier * 0.5)),
    image: `https://picsum.photos/seed/${name}${floor}/500/500`,
    lore: isBoss ? BOSS_LORES[floor] : undefined,
    buffs: []
  };
};

export const calculateBattleAction = (player: UserProfile, monster: Monster, skill?: Skill, petSkill?: Skill) => {
  const pStats = getEffectiveStats(player);
  let damageDealt = 0;
  let damageTaken = 0;
  let manaSpent = 0;
  let isCrit = Math.random() * 100 < pStats.critChance;

  if (skill) {
    if (player.stats.mana >= skill.manaCost) {
      let skillDmg = pStats.elementalDamage * skill.multiplier;
      if (isCrit) skillDmg *= (1 + pStats.critDamage / 100);
      damageDealt += skillDmg;
      manaSpent += skill.manaCost;
    }
  } else if (!petSkill) {
    let basicDmg = pStats.strength * 3;
    if (isCrit) basicDmg *= (1 + pStats.critDamage / 100);
    damageDealt += basicDmg;
  }

  if (petSkill && player.pet) {
    damageDealt += (player.pet.stats.magicDamage * petSkill.multiplier);
    manaSpent += petSkill.manaCost;
  }

  const levelDiff = player.level - monster.level;
  const levelMult = 1 + (levelDiff * 0.05);
  damageDealt *= Math.max(0.1, levelMult);

  damageDealt = Math.max(1, Math.floor(damageDealt - (monster.level * 2)));
  
  const monsterTotalDmg = monster.damage + monster.magicDamage;
  damageTaken = Math.max(1, Math.floor(monsterTotalDmg - (pStats.defense + pStats.magicDefense) / 2));

  return { damageDealt, damageTaken, manaSpent, isCrit };
};

export const getEffectiveStats = (user: UserProfile): Stats => {
  if (!user || !user.stats) {
    return {
      hp: 100, strength: 10, mana: 20, elementalDamage: 5,
      defense: 5, magicDefense: 5, critChance: 5, critDamage: 50
    };
  }

  const base = { ...user.stats };
  
  const equip = user.equipment || {};
  Object.values(equip).forEach((item: any) => {
    if (item && (item as Equipment).stats) {
      Object.entries((item as Equipment).stats).forEach(([stat, val]) => {
        if (typeof val === 'number') {
          (base as any)[stat] = ((base as any)[stat] || 0) + val;
        }
      });
    }
  });

  if (user.buffs && Array.isArray(user.buffs)) {
    user.buffs.forEach(b => {
      if (b && b.stat && typeof b.value === 'number') {
        if (b.type === 'buff') (base as any)[b.stat] = ((base as any)[b.stat] || 0) + b.value;
        else (base as any)[b.stat] = ((base as any)[b.stat] || 0) - b.value;
      }
    });
  }

  return base;
};

export const calculateTotalPower = (user: UserProfile): number => {
  const stats = getEffectiveStats(user);
  let power = 0;
  power += stats.hp / 5;
  power += stats.strength * 5;
  power += stats.mana * 2;
  power += stats.elementalDamage * 8;
  power += stats.defense * 4;
  power += stats.magicDefense * 4;
  power += stats.critChance * 10;
  power += stats.critDamage * 2;
  
  // Add rank multiplier
  const rankIdx = RANK_THRESHOLDS.findIndex(r => r.rank === user.characterRank);
  const rankMult = 1 + (rankIdx * 0.05);
  
  return Math.floor(power * rankMult);
};

export const calculateExpToNext = (level: number): number => Math.floor(100 * Math.pow(1.15, level - 1));

export const getRankForLevel = (level: number): CharacterRank => {
  let currentRank = RANK_THRESHOLDS[0].rank;
  for (const threshold of RANK_THRESHOLDS) {
    if (level >= threshold.level) {
      currentRank = threshold.rank;
    } else {
      break;
    }
  }
  return currentRank;
};

export const getRankColor = (rank: CharacterRank): string => {
  if (rank === CharacterRank.EX) return 'text-yellow-400 glowing-text';
  if (rank.startsWith('SSS')) return 'text-red-600';
  if (rank.startsWith('SS')) return 'text-red-400';
  if (rank.startsWith('S')) return 'text-orange-400';
  if (rank.startsWith('A')) return 'text-pink-400';
  if (rank.startsWith('B')) return 'text-purple-400';
  if (rank.startsWith('C')) return 'text-blue-400';
  if (rank.startsWith('D')) return 'text-green-400';
  if (rank.startsWith('E')) return 'text-slate-300';
  return 'text-slate-500';
};

export const getStaticClassEvolutions = (user: UserProfile): ClassData[] => {
  const rankIdx = RANK_THRESHOLDS.findIndex(r => r.rank === user.characterRank);
  const aRankIdx = RANK_THRESHOLDS.findIndex(r => r.rank === CharacterRank.A);
  
  if (user.evolutionStage === 0) {
    return [
      { name: `Desperto: Lorde ${user.class}`, description: "Um combatente que transcendeu os limites mortais.", bonuses: { strength: 50, hp: 200 } },
      { name: `Desperto: Mestre ${user.class}`, description: "Focado em maestria técnica e controle elemental.", bonuses: { elementalDamage: 40, mana: 150 } }
    ];
  } else {
    return [
      { name: `Relíquia: Divindade ${user.class}`, description: "A forma final, um ser de puro poder.", bonuses: { strength: 200, hp: 1000, elementalDamage: 150 } }
    ];
  }
};

export const getEvolutionStageName = (stage: number): string => {
  if (stage === 0) return 'Iniciante';
  if (stage === 1) return 'Desperto';
  return 'Relíquia';
};

export const checkTitleRequirements = (user: UserProfile): Title[] => {
  const allTitles: Title[] = [
    { id: 't1', name: 'Matador de Slimes', description: 'Eliminou seus primeiros inimigos.', requirement: '10 Monstros Abatidos', bonuses: { strength: 2 }, isUnlocked: (user.monsterKills || 0) >= 10 },
    { id: 't2', name: 'Conquistador de Andares', description: 'Alcançou o andar 20.', requirement: 'Andar 20', bonuses: { hp: 50 }, isUnlocked: (user.maxFloorReached || 0) >= 20 },
    { id: 't3', name: 'Mata-Reis', description: 'Derrotou 5 Bosses.', requirement: '5 Bosses Abatidos', bonuses: { elementalDamage: 10 }, isUnlocked: (user.bossKills || 0) >= 5 },
  ];
  return allTitles;
};

export const generateAIPet = async (element: ElementType, tier: PetTier): Promise<Pet> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Generate a pet for a RPG game. Element: ${element}, Tier: ${tier}. Return a JSON with: "name" (a cool mythological name) and "imagePrompt" (a description for an AI image generator).`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          imagePrompt: { type: Type.STRING }
        },
        required: ["name", "imagePrompt"]
      }
    }
  });

  const data = JSON.parse(response.text || '{"name": "Espírito Guardião", "imagePrompt": "A mystical creature"}') as any;

  return {
    name: data.name,
    tier,
    level: 1,
    exp: 0,
    stats: {
      strength: 10,
      magicDamage: 10,
      hp: 100
    },
    statPoints: 5,
    image: `https://picsum.photos/seed/${data.name}/400/400`,
    skills: [
      { id: 'ps1', name: `Ataque de ${element}`, description: `Ataque elemental básico do pet.`, minLevel: 1, minRank: CharacterRank.F, manaCost: 0, multiplier: 1.5, isUnlocked: true }
    ]
  };
};

export const canEvolvePet = (user: UserProfile): boolean => {
  if (!user.pet) return false;
  const req = getPetEvolveRequirements(user.pet.tier);
  if (!req) return false;
  return (user.petFragments || 0) >= req.fragments && (user.gold || 0) >= req.gold && (user.level || 0) >= req.playerLevel;
};

export const evolvePet = (user: UserProfile): UserProfile => {
  if (!user.pet) return user;
  const req = getPetEvolveRequirements(user.pet.tier);
  const next = getNextPetTier(user.pet.tier);
  if (!next || !req) return user;

  const newUser = { ...user };
  newUser.pet!.tier = next;
  newUser.petFragments = (newUser.petFragments || 0) - req.fragments;
  newUser.gold = (newUser.gold || 0) - req.gold;
  newUser.pet!.statPoints += 20;
  
  return newUser;
};

export const getPetEvolveRequirements = (tier: PetTier): any => {
  const mapping: Record<string, any> = {
    'Comum': { fragments: 10, gold: 500, playerLevel: 10 },
    'Incomum': { fragments: 25, gold: 1500, playerLevel: 25 },
    'Raro': { fragments: 50, gold: 5000, playerLevel: 50 },
    'Muito Raro': { fragments: 100, gold: 15000, playerLevel: 75 },
    'Épico': { fragments: 250, gold: 50000, playerLevel: 100 },
    'Épico+': { fragments: 500, gold: 100000, playerLevel: 125 },
    'Lendário': { fragments: 1000, gold: 250000, playerLevel: 150 },
    'Místico': { fragments: 2500, gold: 1000000, playerLevel: 200 },
  };
  return mapping[tier] || null;
};

export const getNextPetTier = (tier: PetTier): PetTier | null => {
  const tiers: PetTier[] = ['Comum', 'Incomum', 'Raro', 'Muito Raro', 'Épico', 'Épico+', 'Lendário', 'Místico', 'Relíquia'];
  const idx = tiers.indexOf(tier);
  if (idx === -1 || idx === tiers.length - 1) return null;
  return tiers[idx + 1];
};
