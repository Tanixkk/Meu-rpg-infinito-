
export enum ElementRank {
  COMMON = 'COMUM',
  RARE = 'RARO',
  LEGENDARY = 'LENDÁRIO'
}

export type ElementType = 
  | 'Água' | 'Fogo' | 'Terra' | 'Ar' 
  | 'Cristal' | 'Gelo' | 'Metal' | 'Ácido' 
  | 'Sombra' | 'Luz' | 'Magma' | 'Gravidade';

export interface Stats {
  hp: number;
  strength: number;
  mana: number;
  elementalDamage: number;
  defense: number;
  magicDefense: number;
  critChance: number;
  critDamage: number;
}

export interface Buff {
  id: string;
  name: string;
  type: 'buff' | 'debuff';
  stat: keyof Stats;
  value: number;
  duration: number; // em turnos
}

export interface Monster {
  name: string;
  hp: number;
  maxHp: number;
  damage: number;
  magicDamage: number;
  type: 'Normal' | 'Mini-Boss' | 'Boss';
  image: string;
  level: number;
  lore?: string;
  buffs: Buff[];
}

export type PetTier = 'Comum' | 'Incomum' | 'Raro' | 'Muito Raro' | 'Épico' | 'Épico+' | 'Lendário' | 'Místico' | 'Relíquia';

export interface Pet {
  name: string;
  tier: PetTier;
  level: number;
  exp: number;
  stats: {
    strength: number;
    magicDamage: number;
    hp: number;
  };
  statPoints: number;
  image?: string;
  skills: Skill[];
}

export interface Title {
  id: string;
  name: string;
  description: string;
  requirement: string;
  bonuses: Partial<Stats>;
  isUnlocked: boolean;
}

export interface ClassData {
  name: string;
  description: string;
  bonuses: Partial<Stats>;
}

export type ClassType = 'Guerreiro' | 'Mago' | 'Ladino' | 'Paladino' | 'Assassino' | 'Tank' | 'Necromante';

export interface CreatedAsset {
  id?: string;
  name: string;
  type: 'item' | 'magia';
  stats: any;
  creator: string;
  cost?: number;
}

export type ItemType = 'Arma' | 'Armadura' | 'Amuleto' | 'Escudo' | 'Elmo';
export type Rarity = 'Comum' | 'Raro' | 'Lendário' | 'Mítico';

export interface MiningSession {
  mineralId: string;
  startTime: number;
  duration: number;
  expectedYield: number;
}

export interface ChatMessage {
  id: string;
  sender: string;
  content: string;
  timestamp: number;
  isAdmin: boolean;
  channel?: string;
}

export interface UserProfile {
  id: string;
  username: string;
  avatar: string;
  backgroundPhoto?: string;
  level: number;
  exp: number;
  expToNext: number;
  currentFloor: number;
  maxFloorReached: number;
  characterRank: CharacterRank;
  class: string;
  evolutionStage: number;
  element: ElementType;
  stats: Stats;
  statPoints: number;
  gold: number;
  skills: Skill[];
  inventory: Equipment[];
  minerals: Record<string, number>;
  activeMining: MiningSession | null;
  missions: Mission[];
  adventureLocations: AdventureLocation[];
  monsterKills: number;
  bossKills: number;
  deaths: number;
  totalPower: number;
  currentTitle: Title | null;
  ownedTitles: Title[];
  pet: Pet | null;
  petFragments: number;
  buffs: Buff[];
  equipment: {
    weapon: Equipment | null;
    armor: Equipment | null;
    trinket: Equipment | null;
    shield: Equipment | null;
    helmet: Equipment | null;
  };
}

export interface Mission {
  id: string;
  title: string;
  description: string;
  target: number;
  current: number;
  rewardExp: number;
  rewardGold: number;
  isCompleted: boolean;
  floorRange?: [number, number];
  targetItemId?: string;
  type: 'kill' | 'collect' | 'escort';
}

export interface AdventureLocation {
  id: string;
  name: string;
  type: 'Vilarejo' | 'Reino';
  description: string;
  quests: Mission[];
}

export enum CharacterRank {
  F = 'F', 
  E = 'E', 'E+' = 'E+', 
  D = 'D', 'D+' = 'D+', 
  C = 'C', 'C+' = 'C+', 
  B = 'B', 'B+' = 'B+', 
  A = 'A', 'A+' = 'A+', 
  S = 'S', 'S+' = 'S+', 
  SS = 'SS', 'SS+' = 'SS+', 
  SSS = 'SSS', 
  EX = 'EX'
}

export interface Skill {
  id: string;
  name: string;
  description: string;
  minLevel: number;
  minRank: CharacterRank;
  manaCost: number;
  multiplier: number;
  isUnlocked: boolean;
  effect?: Buff;
}

export interface Equipment {
  id: string;
  name: string;
  type: ItemType;
  rarity: Rarity;
  stats: Partial<Stats>;
  levelRequired: number;
  description: string;
}

export interface DamageEffect {
  id: number;
  value: number;
  type: 'physical' | 'elemental' | 'monster' | 'crit' | 'pet';
  x: number;
  y: number;
}
