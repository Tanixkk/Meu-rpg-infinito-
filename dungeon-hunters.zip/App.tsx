
import React, { useState, useEffect } from 'react';
import { UserProfile } from './types';
import Auth from './components/Auth';
import CharacterCreation from './components/CharacterCreation';
import Dashboard from './components/Dashboard';
import { supabase } from './supabase';
import { calculateTotalPower } from './services/gameEngine';

const App: React.FC = () => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [needsCreation, setNeedsCreation] = useState(false);
  const [loading, setLoading] = useState(true);
  const [schemaError, setSchemaError] = useState(false);

  // Função robusta para salvar no Supabase e LocalStorage
  const handleUpdateUser = async (updated: UserProfile) => {
    // Recalcula o poder para garantir ranking correto
    const power = calculateTotalPower(updated);
    const finalProfile = { ...updated, totalPower: power };
    
    setUser(finalProfile);
    
    try {
      const slimProfile = { ...finalProfile };
      if (slimProfile.avatar && slimProfile.avatar.length > 2000) slimProfile.avatar = "";
      if (slimProfile.backgroundPhoto && slimProfile.backgroundPhoto.length > 2000) slimProfile.backgroundPhoto = undefined;
      localStorage.setItem('dungeon_hunters_profile', JSON.stringify(slimProfile));
    } catch (e) {
      console.warn("LocalStorage cota excedida.");
    }

    try {
      const { error } = await supabase
        .from('profiles')
        .upsert(finalProfile, { onConflict: 'id' });
      
      if (error) {
        if (error.message.includes('profiles')) setSchemaError(true);
        console.error("Erro ao sincronizar com Supabase:", error.message);
      }
    } catch (e) {
      console.error("Erro crítico de rede:", e);
    }
  };

  const handleCharacterCreated = async (initialProfile: UserProfile) => {
    const { data: { session } } = await supabase.auth.getSession();
    if (session) {
      const finalProfile = { ...initialProfile, id: session.user.id };
      await handleUpdateUser(finalProfile);
      setNeedsCreation(false);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setIsAuthenticated(false);
    setUser(null);
    setNeedsCreation(false);
    localStorage.removeItem('zenith_temp_username');
  };

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (session) {
        setIsAuthenticated(true);
        fetchProfile(session.user.id);
      } else {
        setIsAuthenticated(false);
        setUser(null);
        setLoading(false);
      }
    });

    const fetchProfile = async (userId: string) => {
      try {
        const { data: profile, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', userId)
          .single();

        if (error) {
          if (error.message.includes('cache') || error.message.includes('profiles')) {
            setSchemaError(true);
          }
          setNeedsCreation(true);
        } else if (profile) {
          setUser(profile as UserProfile);
          setNeedsCreation(false);
        }
      } catch (err) {
        console.error("Erro ao buscar perfil:", err);
      } finally {
        setLoading(false);
      }
    };

    return () => subscription.unsubscribe();
  }, []);

  if (schemaError) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-8 text-center">
        <div className="rpg-card p-10 rounded-3xl border-red-500 border-2 max-w-lg">
          <span className="text-6xl mb-6 block">⚠️</span>
          <h2 className="text-2xl font-fantasy font-black text-red-500 mb-4 uppercase">Configuração Necessária</h2>
          <p className="text-slate-300 mb-6">
            O banco de dados Supabase ainda não foi configurado. Você precisa criar as tabelas <code className="text-indigo-400">profiles</code> e <code className="text-indigo-400">chat_messages</code> no seu painel do Supabase.
          </p>
          <div className="bg-slate-900 p-4 rounded-xl text-left text-xs text-slate-400 font-mono overflow-x-auto mb-6">
             Acesse o arquivo <code className="text-white">supabase.ts</code> no código, copie o script SQL comentado lá e cole no <strong>SQL Editor</strong> do seu dashboard Supabase.
          </div>
          <button 
            onClick={() => window.location.reload()}
            className="bg-indigo-600 px-8 py-3 rounded-xl font-black uppercase hover:bg-indigo-500 transition-all"
          >
            Já configurei, recarregar
          </button>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center gap-6">
        <div className="relative w-24 h-24">
           <div className="absolute inset-0 animate-ping rounded-full bg-indigo-500/20"></div>
           <div className="relative animate-spin rounded-full h-24 w-24 border-t-4 border-indigo-500 border-r-4 border-r-transparent"></div>
        </div>
        <p className="text-white font-fantasy text-xl animate-pulse tracking-widest uppercase">Dungeon Hunters</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Auth onLogin={() => setLoading(true)} />;
  }

  if (needsCreation) {
    const tempUsername = localStorage.getItem('zenith_temp_username') || "Viajante";
    return <CharacterCreation username={tempUsername} onComplete={handleCharacterCreated} />;
  }

  return user ? (
    <Dashboard user={user} onUpdateUser={handleUpdateUser} onLogout={handleLogout} />
  ) : null;
};

export default App;
