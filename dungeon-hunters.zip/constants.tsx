
import { AdventureLocation, CharacterRank, ElementType, ElementRank, Skill, Mission } from './types';

export const BOSS_LORES: Record<number, string> = {
  10: "O Soberano de Ferro: Uma armadura vazia que ganhou vida no andar 10.",
  20: "O Devorador de Mana: Uma besta etérea que se alimenta de magia no andar 20.",
  30: "A Rainha das Sombras: Regente amaldiçoada das profundezas no andar 30.",
  40: "O Titã de Magma: Uma força da natureza despertada no andar 40.",
  50: "O Ceifador Dimensional: Ser que corta a própria realidade no andar 50.",
};

// Pool de missões para o Mundo Aberto
export const MISSION_POOL: Mission[] = [
  // Rank F / E (Andares 1-15)
  { id: 'q_f1', title: 'Infestação de Slimes', description: 'Elimine os slimes que bloqueiam o caminho.', target: 10, current: 0, rewardExp: 200, rewardGold: 150, isCompleted: false, floorRange: [1, 5], type: 'kill' },
  { id: 'q_f2', title: 'Ervas Medicinais', description: 'Colete ervas raras que nascem nas pedras.', target: 5, current: 0, rewardExp: 150, rewardGold: 100, isCompleted: false, floorRange: [3, 8], type: 'collect', targetItemId: 'Erva de Cura' },
  { id: 'q_f3', title: 'Escolta de Mercador', description: 'Proteja o mercador até o andar 10.', target: 10, current: 0, rewardExp: 500, rewardGold: 300, isCompleted: false, type: 'escort' },
  
  // Rank D / C (Andares 15-40)
  { id: 'q_d1', title: 'Ossos de Esqueleto', description: 'Colete ossos amaldiçoados no setor sombrio.', target: 8, current: 0, rewardExp: 800, rewardGold: 500, isCompleted: false, floorRange: [15, 25], type: 'collect', targetItemId: 'Osso Maldito' },
  { id: 'q_d2', title: 'Caça aos Goblins', description: 'Reduza a população de saqueadores nos andares 20-30.', target: 20, current: 0, rewardExp: 1000, rewardGold: 600, isCompleted: false, floorRange: [20, 30], type: 'kill' },
  { id: 'q_d3', title: 'Essência de Mana', description: 'Extraia energia dos monstros mágicos.', target: 12, current: 0, rewardExp: 1200, rewardGold: 800, isCompleted: false, floorRange: [25, 35], type: 'collect', targetItemId: 'Essência Azul' },

  // Rank B / A (Andares 40-70)
  { id: 'q_b1', title: 'Escamas de Dragão', description: 'Obtenha escamas dos draconídeos no andar 45+.', target: 10, current: 0, rewardExp: 3000, rewardGold: 2000, isCompleted: false, floorRange: [45, 60], type: 'collect', targetItemId: 'Escama Rubra' },
  { id: 'q_b2', title: 'Elite do Abismo', description: 'Derrote os cavaleiros negros da torre.', target: 15, current: 0, rewardExp: 4500, rewardGold: 3500, isCompleted: false, floorRange: [50, 70], type: 'kill' },
  { id: 'q_a1', title: 'Lágrima de Anjo', description: 'Colete as relíquias sagradas protegidas pela luz.', target: 5, current: 0, rewardExp: 7000, rewardGold: 5000, isCompleted: false, floorRange: [60, 80], type: 'collect', targetItemId: 'Lágrima Sagrada' },
];

export const MISSION_TEMPLATES: Mission[] = [
  { id: 'm_init_1', title: 'O Despertar', description: 'Derrote seu primeiro monstro na torre.', target: 1, current: 0, rewardExp: 100, rewardGold: 50, isCompleted: false, type: 'kill' },
];

export const WORLD_LOCATIONS: AdventureLocation[] = [
  { id: 'v1', name: 'Oakhaven', type: 'Vilarejo', description: 'Um refúgio rústico cercado por carvalhos antigos.', quests: [] },
  { id: 'v2', name: 'Crystalbay', type: 'Vilarejo', description: 'Vilarejo costeiro onde as águas brilham.', quests: [] },
  { id: 'v3', name: 'Sandpoint', type: 'Vilarejo', description: 'Posto comercial nas dunas do deserto.', quests: [] },
  { id: 'v4', name: 'Shadowglen', type: 'Vilarejo', description: 'Localizado em um pântano eterno.', quests: [] },
  { id: 'v5', name: 'Snowpeak', type: 'Vilarejo', description: 'O ponto mais alto e frio da cordilheira.', quests: [] },
  { id: 'r1', name: 'Reino de Ironforge', type: 'Reino', description: 'A capital industrial escavada na montanha.', quests: [] },
  { id: 'r2', name: 'Reino de Silvermoon', type: 'Reino', description: 'Majestosa cidade élfica banhada pelo luar.', quests: [] },
];

export const MINERALS = [
  { id: 'coal', name: 'Carvão', rarity: 'Comum', duration: 10000, color: 'bg-slate-700' },
  { id: 'iron', name: 'Ferro', rarity: 'Comum', duration: 30000, color: 'bg-slate-400' },
  { id: 'silver', name: 'Prata', rarity: 'Raro', duration: 60000, color: 'bg-slate-300' },
  { id: 'gold', name: 'Ouro', rarity: 'Raro', duration: 120000, color: 'bg-yellow-600' },
  { id: 'mithril', name: 'Mithril', rarity: 'Lendário', duration: 300000, color: 'bg-cyan-400' },
  { id: 'obsidian', name: 'Obsidiana', rarity: 'Lendário', duration: 600000, color: 'bg-purple-900' },
  { id: 'adamantite', name: 'Adamantite', rarity: 'Mítico', duration: 1200000, color: 'bg-red-600' },
];

export const ELEMENTS = [
  { name: 'Água', rank: ElementRank.COMMON, color: 'text-blue-400', description: 'O fluxo imparável da vida.' },
  { name: 'Fogo', rank: ElementRank.COMMON, color: 'text-red-500', description: 'A chama devoradora da destruição.' },
  { name: 'Terra', rank: ElementRank.COMMON, color: 'text-amber-700', description: 'A resistência inabalável do solo.' },
  { name: 'Ar', rank: ElementRank.COMMON, color: 'text-sky-300', description: 'A velocidade invisível do vento.' },
  { name: 'Cristal', rank: ElementRank.RARE, color: 'text-pink-400', description: 'Refração mágica e dureza extrema.' },
  { name: 'Gelo', rank: ElementRank.RARE, color: 'text-cyan-200', description: 'Frio absoluto que paralisa o tempo.' },
  { name: 'Metal', rank: ElementRank.RARE, color: 'text-slate-400', description: 'Condutor de energia e força bruta.' },
  { name: 'Ácido', rank: ElementRank.RARE, color: 'text-lime-500', description: 'Corrosão que derrete qualquer defesa.' },
  { name: 'Sombra', rank: ElementRank.LEGENDARY, color: 'text-purple-900', description: 'O vazio primordial que tudo consome.' },
  { name: 'Luz', rank: ElementRank.LEGENDARY, color: 'text-yellow-200', description: 'A pureza radiante que cega o mal.' },
  { name: 'Magma', rank: ElementRank.LEGENDARY, color: 'text-orange-700', description: 'A fusão devastadora entre terra e fogo.' },
  { name: 'Gravidade', rank: ElementRank.LEGENDARY, color: 'text-indigo-600', description: 'O controle absoluto sobre o espaço.' },
];

export const CLASSES = [
  { name: 'Guerreiro', description: 'Especialista em combate físico e alta resistência.', bonuses: { hp: 50, strength: 10, mana: 5, elementalDamage: 2, defense: 5 } },
  { name: 'Mago', description: 'Mestre das artes arcanas e dano elemental massivo.', bonuses: { hp: 20, strength: 2, mana: 40, elementalDamage: 15, magicDefense: 8 } },
  { name: 'Ladino', description: 'Ágil e mortal, focado em críticos e velocidade.', bonuses: { hp: 30, strength: 8, mana: 15, critChance: 10, critDamage: 20 } },
  { name: 'Paladino', description: 'Guardião sagrado equilibrado.', bonuses: { hp: 60, strength: 6, mana: 25, defense: 8, magicDefense: 8 } },
  { name: 'Assassino', description: 'Mestre da furtividade e golpes fatais.', bonuses: { hp: 25, strength: 12, critChance: 15, critDamage: 50 } },
  { name: 'Tank', description: 'Parede viva intransponível.', bonuses: { hp: 150, defense: 20, magicDefense: 10, strength: 4 } },
  { name: 'Necromante', description: 'Comanda as forças da morte e drenagem.', bonuses: { hp: 40, mana: 50, elementalDamage: 10, magicDefense: 15 } }
];

export const RANK_THRESHOLDS: { rank: CharacterRank; level: number }[] = [
  { rank: CharacterRank.F, level: 1 },
  { rank: CharacterRank.E, level: 5 },
  { rank: CharacterRank['E+'], level: 12 },
  { rank: CharacterRank.D, level: 22 },
  { rank: CharacterRank['D+'], level: 35 },
  { rank: CharacterRank.C, level: 50 },
  { rank: CharacterRank['C+'], level: 70 },
  { rank: CharacterRank.B, level: 95 },
  { rank: CharacterRank['B+'], level: 125 },
  { rank: CharacterRank.A, level: 160 },
  { rank: CharacterRank['A+'], level: 205 },
  { rank: CharacterRank.S, level: 260 },
  { rank: CharacterRank['S+'], level: 330 },
  { rank: CharacterRank.SS, level: 420 },
  { rank: CharacterRank['SS+'], level: 530 },
  { rank: CharacterRank.SSS, level: 660 },
  { rank: CharacterRank.EX, level: 850 },
];

export const getBaseSkillsForElement = (element: ElementType): Skill[] => {
  return [
    { id: 'skill_1', name: `Faísca de ${element}`, description: `Dano básico rápido de ${element}.`, minLevel: 1, minRank: CharacterRank.F, manaCost: 8, multiplier: 1.2, isUnlocked: true },
    { id: 'skill_2', name: `Barreira de ${element}`, description: `Aumenta defesas temporariamente.`, minLevel: 12, minRank: CharacterRank['E+'], manaCost: 20, multiplier: 0, isUnlocked: false },
    { id: 'skill_3', name: `Vendaval de ${element}`, description: `Ataque múltiplo violento.`, minLevel: 35, minRank: CharacterRank['D+'], manaCost: 45, multiplier: 3.5, isUnlocked: false },
    { id: 'skill_4', name: `Aniquilação de ${element}`, description: `Libera todo o potencial do rank B.`, minLevel: 95, minRank: CharacterRank.B, manaCost: 90, multiplier: 7.0, isUnlocked: false },
    { id: 'skill_ultimate', name: `Avatar de ${element}`, description: `Transformação divina temporária.`, minLevel: 260, minRank: CharacterRank.S, manaCost: 250, multiplier: 15.0, isUnlocked: false },
  ];
};
