
import React, { useState, useEffect } from 'react';
import { UserProfile, MiningSession } from '../types';
import { MINERALS } from '../constants';

interface MiningProps {
  user: UserProfile;
  onUpdateUser: (updated: UserProfile) => void;
}

const Mining: React.FC<MiningProps> = ({ user, onUpdateUser }) => {
  const [timeLeft, setTimeLeft] = useState<number>(0);

  useEffect(() => {
    if (user.activeMining) {
      const interval = setInterval(() => {
        const remaining = user.activeMining!.startTime + user.activeMining!.duration - Date.now();
        if (remaining <= 0) {
          finishMining(false);
          clearInterval(interval);
        } else {
          setTimeLeft(remaining);
        }
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [user.activeMining]);

  const startMining = (mineralId: string) => {
    if (user.activeMining) return;
    const mineral = MINERALS.find(m => m.id === mineralId)!;
    const session: MiningSession = {
      mineralId,
      startTime: Date.now(),
      duration: mineral.duration,
      expectedYield: Math.floor(Math.random() * 5) + 3
    };
    onUpdateUser({ ...user, activeMining: session });
  };

  const finishMining = (skipped: boolean) => {
    if (!user.activeMining) return;
    const newUser = { ...user };
    const yieldAmount = skipped ? Math.floor(user.activeMining.expectedYield / 2) : user.activeMining.expectedYield;
    
    newUser.minerals[user.activeMining.mineralId] += yieldAmount;
    newUser.activeMining = null;

    // Mission Progress
    newUser.missions = newUser.missions.map(m => {
      if (m.id === 'm2' && !m.isCompleted) {
        const current = m.current + 1;
        const isCompleted = current >= m.target;
        if (isCompleted) {
          newUser.exp += m.rewardExp;
          newUser.gold += m.rewardGold;
        }
        return { ...m, current: Math.min(current, m.target), isCompleted };
      }
      return m;
    });

    onUpdateUser(newUser);
  };

  const formatTime = (ms: number) => {
    const totalSec = Math.floor(ms / 1000);
    const min = Math.floor(totalSec / 60);
    const sec = totalSec % 60;
    return `${min}:${sec < 10 ? '0' : ''}${sec}`;
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-fantasy font-black">Cavernas de Mineração</h2>
          <p className="text-slate-400">Envie mineradores para coletar recursos raros</p>
        </div>
      </div>

      {user.activeMining ? (
        <div className="rpg-card rounded-2xl p-12 flex flex-col items-center text-center animate-pulse">
          <div className="text-6xl mb-4">⛏️</div>
          <h3 className="text-2xl font-bold mb-2">Minerando: {MINERALS.find(m => m.id === user.activeMining?.mineralId)?.name}</h3>
          <p className="text-slate-400 mb-8 text-sm uppercase font-black">Tempo Restante: <span className="text-white text-xl">{formatTime(timeLeft)}</span></p>
          
          <div className="w-full max-w-md h-4 bg-slate-900 rounded-full overflow-hidden border border-slate-700 mb-8">
            <div 
              className="h-full bg-indigo-500 transition-all duration-1000" 
              style={{ width: `${100 - (timeLeft / user.activeMining.duration) * 100}%` }}
            ></div>
          </div>

          <button 
            onClick={() => finishMining(true)}
            className="bg-red-600/20 hover:bg-red-600 border border-red-600/50 px-8 py-2 rounded-lg font-bold text-red-200 transition-all"
          >
            Pular Mineração (Perde 50% dos Minérios)
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {MINERALS.map(m => (
            <div key={m.id} className="rpg-card rounded-2xl p-6 border-b-4 border-slate-800 hover:border-indigo-500 transition-all">
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 rounded-lg ${m.color} flex items-center justify-center text-2xl`}>💎</div>
                  <div>
                    <h4 className="font-bold">{m.name}</h4>
                    <p className="text-[10px] text-slate-500 uppercase font-black">{m.rarity}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xs text-slate-500 uppercase font-black">Tempo</p>
                  <p className="font-bold">{formatTime(m.duration)}</p>
                </div>
              </div>
              <p className="text-xs text-slate-400 mb-6 italic">Encontrado em camadas profundas da terra.</p>
              <button 
                onClick={() => startMining(m.id)}
                className="w-full bg-slate-800 hover:bg-indigo-600 py-3 rounded-xl font-bold transition-all"
              >
                COMEÇAR MINERAÇÃO
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Mining;
