
import React, { useState, useEffect } from 'react';
import { UserProfile, CharacterRank } from '../types';
import { supabase } from '../supabase';
import { getRankColor, getRankForLevel } from '../services/gameEngine';

interface LeaderboardProps {
  user: UserProfile;
  onPreviewPlayer: (id: string) => void;
}

const Leaderboard: React.FC<LeaderboardProps> = ({ user, onPreviewPlayer }) => {
  const [players, setPlayers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const fetchPlayers = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, username, avatar, level, totalPower, currentTitle')
        .order('totalPower', { ascending: false })
        .limit(100);
      
      if (error) {
        console.error("Erro Supabase Ranking:", error);
        setErrorMsg("Não foi possível carregar o ranking no momento.");
      } else if (data) {
        setPlayers(data.map(p => ({
          ...p,
          power: p.totalPower || 0,
          title: p.currentTitle?.name || 'Sem Título',
          isMe: p.id === user.id,
          rank: getRankForLevel(p.level)
        })));
        setErrorMsg(null);
      }
    } catch (err) {
      console.error("Erro fatal ao buscar ranking:", err);
      setErrorMsg("Erro de conexão com a torre.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPlayers();
    
    const channel = supabase.channel('ranking_updates')
      .on('postgres_changes', { event: '*', table: 'profiles' }, () => {
        fetchPlayers();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user.id]);

  if (loading) return (
    <div className="p-20 flex flex-col items-center justify-center gap-4">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-500"></div>
      <p className="text-slate-500 font-black uppercase text-[10px] animate-pulse tracking-[0.3em]">Consultando Registros da Torre...</p>
    </div>
  );

  if (errorMsg) return (
    <div className="p-20 text-center">
       <p className="text-red-500 font-black uppercase mb-4">{errorMsg}</p>
       <button onClick={() => { setLoading(true); fetchPlayers(); }} className="bg-slate-800 px-6 py-2 rounded-xl text-xs font-black">TENTAR NOVAMENTE</button>
    </div>
  );

  return (
    <div className="space-y-6 animate-in fade-in duration-700">
      <div className="flex justify-between items-end mb-4">
        <div>
           <h2 className="text-4xl font-fantasy font-black glowing-text mb-1 uppercase">Hall da Fama</h2>
           <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest">Os 100 Caçadores Mais Poderosos da Existência</p>
        </div>
      </div>

      <div className="rpg-card rounded-[2rem] overflow-hidden border border-slate-800 shadow-2xl">
        <div className="overflow-x-auto custom-scrollbar">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-900/80 text-[10px] font-black uppercase text-slate-500 tracking-tighter">
                <th className="px-8 py-5">Pos</th>
                <th className="px-8 py-5">Caçador / Título</th>
                <th className="px-8 py-5 text-center">Rank</th>
                <th className="px-8 py-5">Poder</th>
                <th className="px-8 py-5 text-right">Ação</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {players.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-8 py-20 text-center text-slate-600 italic">Nenhum caçador registrado nos anais da história...</td>
                </tr>
              ) : (
                players.map((p, i) => (
                  <tr key={p.id} className={`transition-all duration-300 ${p.isMe ? 'bg-indigo-600/10' : 'hover:bg-slate-800/30'}`}>
                    <td className="px-8 py-5">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-black text-xs ${
                        i === 0 ? 'bg-yellow-500 text-slate-900 shadow-[0_0_15px_#eab308]' : 
                        i === 1 ? 'bg-slate-300 text-slate-900' :
                        i === 2 ? 'bg-amber-700 text-white' : 'text-slate-500'
                      }`}>
                        {i + 1}
                      </div>
                    </td>
                    <td className="px-8 py-5">
                      <div className="flex items-center gap-4">
                        <div className="relative">
                          <img src={p.avatar} className="w-12 h-12 rounded-2xl border border-slate-700 bg-slate-950 object-cover shadow-lg" />
                          {p.isMe && <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 border-2 border-slate-950 rounded-full"></div>}
                        </div>
                        <div className="flex flex-col">
                          <span className={`font-bold text-base tracking-tight ${p.isMe ? 'text-indigo-400' : 'text-slate-200'}`}>
                            {p.username || "Desconhecido"}
                          </span>
                          <span className="text-[9px] uppercase font-black text-indigo-500/80 tracking-widest">{p.title}</span>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-5 text-center">
                       <span className={`px-3 py-1 bg-slate-800 rounded-full text-[10px] font-black uppercase ${getRankColor(p.rank)}`}>
                         {p.rank} (NVL {p.level})
                       </span>
                    </td>
                    <td className="px-8 py-5">
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-black text-yellow-500 drop-shadow-[0_0_10px_rgba(234,179,8,0.3)]">{p.power.toLocaleString()}</span>
                        <span className="text-xs">⚡</span>
                      </div>
                    </td>
                    <td className="px-8 py-5 text-right">
                      <button 
                        onClick={() => onPreviewPlayer(p.id)} 
                        className="bg-indigo-600/10 hover:bg-indigo-600 text-indigo-400 hover:text-white px-5 py-2 rounded-xl text-[10px] font-black uppercase transition-all active:scale-90 border border-indigo-600/20"
                      >
                        Ver Ficha
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Leaderboard;
