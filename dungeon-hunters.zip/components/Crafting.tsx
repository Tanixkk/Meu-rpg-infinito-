
import React from 'react';
import { UserProfile, Equipment, Rarity, ItemType } from '../types';

interface CraftingProps {
  user: UserProfile;
  onUpdateUser: (updated: UserProfile) => void;
}

const Crafting: React.FC<CraftingProps> = ({ user, onUpdateUser }) => {
  
  const recipes = [
    { id: 'c1', name: 'Lâmina de Ferro', type: 'Arma' as ItemType, rarity: 'Comum' as Rarity, cost: { iron: 10, coal: 5 }, bonus: { strength: 25 } },
    { id: 'c2', name: 'Peitoral de Prata', type: 'Armadura' as ItemType, rarity: 'Raro' as Rarity, cost: { silver: 15, coal: 10 }, bonus: { hp: 200, defense: 10 } },
    { id: 'c3', name: 'Elmo de Ouro', type: 'Elmo' as ItemType, rarity: 'Raro' as Rarity, cost: { gold: 12, coal: 15 }, bonus: { magicDefense: 15, mana: 80 } },
    { id: 'c4', name: 'Escudo de Obsidiana', type: 'Escudo' as ItemType, rarity: 'Raro' as Rarity, cost: { obsidian: 8, iron: 20 }, bonus: { defense: 30, hp: 100 } },
    { id: 'c5', name: 'Aniquilador de Mithril', type: 'Arma' as ItemType, rarity: 'Lendário' as Rarity, cost: { mithril: 5, gold: 15, obsidian: 5 }, bonus: { strength: 150, critDamage: 40 } },
    { id: 'c6', name: 'Manto de Adamantite', type: 'Armadura' as ItemType, rarity: 'Mítico' as Rarity, cost: { adamantite: 3, mithril: 5, gold: 30 }, bonus: { hp: 1000, defense: 80, magicDefense: 80 } },
  ];

  const handleCraft = (recipe: any) => {
    const newUser = { ...user };
    
    for (const [mineral, amount] of Object.entries(recipe.cost)) {
      if ((newUser.minerals[mineral] || 0) < (amount as number)) {
        alert(`Recursos insuficientes de ${mineral}!`);
        return;
      }
    }

    for (const [mineral, amount] of Object.entries(recipe.cost)) {
      newUser.minerals[mineral] -= amount as number;
    }

    const newItem: Equipment = {
      id: Math.random().toString(36).substr(2, 9),
      name: recipe.name,
      type: recipe.type,
      rarity: recipe.rarity,
      stats: recipe.bonus,
      levelRequired: 1,
      description: `Forjado mestre: ${recipe.rarity}.`
    };

    newUser.inventory.push(newItem);
    onUpdateUser(newUser);
    alert(`${recipe.name} criado com sucesso!`);
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-fantasy font-black">Mesa de Forja Profissional</h2>
          <p className="text-slate-400">Transforme minérios brutos em poder bélico</p>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {Object.entries(user.minerals).map(([name, qty]) => (
            <div key={name} className="bg-slate-900 border border-slate-800 px-3 py-1 rounded-lg min-w-[80px]">
              <span className="text-[8px] text-slate-500 uppercase font-black block">{name}</span>
              <span className="font-bold text-xs text-indigo-400">{qty}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {recipes.map(r => (
          <div key={r.id} className={`rpg-card rounded-3xl p-6 border-l-8 transition-all hover:scale-[1.02] ${
            r.rarity === 'Mítico' ? 'border-red-600 shadow-[0_0_15px_rgba(220,38,38,0.3)]' :
            r.rarity === 'Lendário' ? 'border-yellow-500 shadow-[0_0_10px_rgba(234,179,8,0.2)]' :
            r.rarity === 'Raro' ? 'border-blue-500' : 'border-slate-700'
          }`}>
            <div className="flex flex-col md:flex-row justify-between gap-6">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <span className="text-3xl">{r.type === 'Arma' ? '⚔️' : r.type === 'Armadura' ? '🛡️' : r.type === 'Escudo' ? '🧱' : r.type === 'Elmo' ? '🪖' : '📿'}</span>
                  <div>
                    <h3 className="text-xl font-bold text-white">{r.name}</h3>
                    <p className={`text-[10px] font-black uppercase ${r.rarity === 'Mítico' ? 'text-red-500' : r.rarity === 'Lendário' ? 'text-yellow-500' : 'text-blue-400'}`}>{r.rarity}</p>
                  </div>
                </div>
                
                <div className="bg-black/20 rounded-xl p-3 space-y-1">
                  {Object.entries(r.bonus).map(([stat, val]) => (
                    <p key={stat} className="text-[11px] text-green-500 font-black flex justify-between uppercase">
                      <span>{stat}</span>
                      <span>+{val}</span>
                    </p>
                  ))}
                </div>
              </div>

              <div className="flex flex-col justify-between items-end min-w-[160px]">
                <div className="text-right w-full">
                  <p className="text-[10px] text-slate-500 uppercase font-black mb-2 border-b border-slate-800 pb-1">Materiais:</p>
                  <div className="space-y-1">
                    {Object.entries(r.cost).map(([min, qty]) => (
                      <div key={min} className={`text-[10px] font-bold flex justify-between gap-4 ${user.minerals[min] >= (qty as number) ? 'text-slate-400' : 'text-red-500'}`}>
                        <span className="capitalize">{min}</span>
                        <span>{user.minerals[min]}/{qty}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <button 
                  onClick={() => handleCraft(r)}
                  className="mt-4 w-full bg-indigo-600 hover:bg-indigo-500 py-2.5 rounded-xl font-black text-xs transition-all shadow-lg shadow-indigo-900/40"
                >
                  FORJAR ITEM
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Crafting;
