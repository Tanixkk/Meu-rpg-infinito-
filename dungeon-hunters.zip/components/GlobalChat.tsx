
import React, { useState, useEffect, useRef } from 'react';
import { UserProfile, ChatMessage, Equipment, Skill, CreatedAsset, ItemType, Rarity, CharacterRank, ElementType } from '../types';
import { calculateTotalPower, calculateExpToNext, getRankForLevel } from '../services/gameEngine';
import { ELEMENTS, CLASSES, getBaseSkillsForElement } from '../constants';
import { supabase } from '../supabase';

interface GlobalChatProps {
  user: UserProfile;
  onUpdateUser: (updated: UserProfile) => void;
}

const GlobalChat: React.FC<GlobalChatProps> = ({ user, onUpdateUser }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [staffMessages, setStaffMessages] = useState<ChatMessage[]>([]);
  const [activeChatTab, setActiveChatTab] = useState<'global' | 'staff'>('global');
  const [input, setInput] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);
  const isAdmin = user.username === 'Tanixkk';

  useEffect(() => {
    const fetchMessages = async () => {
      const { data: globalMsgs } = await supabase
        .from('chat_messages')
        .select('*')
        .eq('channel', 'global')
        .order('timestamp', { ascending: true })
        .limit(100);
      
      if (globalMsgs) setMessages(globalMsgs);

      if (isAdmin) {
        const { data: staffMsgs } = await supabase
          .from('chat_messages')
          .select('*')
          .eq('channel', 'staff')
          .order('timestamp', { ascending: true })
          .limit(100);
        if (staffMsgs) setStaffMessages(staffMsgs);
      }
    };
    
    fetchMessages();

    const channel = supabase.channel('public_chat_v2')
      .on('postgres_changes', { event: 'INSERT', table: 'chat_messages' }, payload => {
        const msg = payload.new as ChatMessage;
        if (msg.channel === 'global') setMessages(prev => [...prev.filter(m => m.id !== msg.id), msg].slice(-100));
        else if (msg.channel === 'staff' && isAdmin) setStaffMessages(prev => [...prev.filter(m => m.id !== msg.id), msg].slice(-100));
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [isAdmin]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, staffMessages, activeChatTab]);

  const parseStats = (statsStr: string) => {
    const stats: any = {};
    if (!statsStr) return stats;
    const pairs = statsStr.split(',');
    pairs.forEach(p => {
      const [k, v] = p.split(':');
      if (k && v) stats[k.trim()] = parseFloat(v.trim());
    });
    return stats;
  };

  const getTargetProfile = async (targetName: string): Promise<UserProfile | null> => {
    if (!targetName) return null;
    const { data } = await supabase.from('profiles').select('*').eq('username', targetName).single();
    return data as UserProfile;
  };

  const executeCommand = async (cmd: string): Promise<string> => {
    const parts = cmd.split(' ');
    const command = parts[0].toLowerCase();

    // COMANDOS PÚBLICOS
    if (command === '/help') {
      return `❓ MANUAL ADM:\n
      /Criar [nome] [status:valor] [adm] [alvo?] - Salva no catálogo e entrega (se houver alvo).\n
      /Magia [nome] [multiplier:valor] [mana] - Salva magia no catálogo.\n
      /Criação - Lista tudo o que foi criado.\n
      /Give [qtd] [alvo] [nome] - Dá XP, Gold ou Item do catálogo.\n
      /Addmagia [nome] [alvo] - Ensina magia do catálogo a alguém.\n
      /Additem [nome] [preço] - Põe item do catálogo na loja.\n
      /Remove [nome] [alvo] - 'alvo' pode ser nome do player ou 'global'.\n
      /Elemento [alvo] [elemento] - Troca elemento e reset de magias.`;
    }

    if (command === '/tags') {
      return `🏷️ TAGS: hp, strength, mana, elementalDamage, defense, magicDefense, critChance, critDamage`;
    }

    if (!isAdmin) return "❌ Acesso restrito ao Administrador Tanixkk.";

    switch (command) {
      case '/criar': {
        const [_, name, bonusStr, creator, targetUser] = parts;
        if (!name || !bonusStr || !creator) return "Uso: /Criar [Nome] [status:valor] [SeuNome] [Alvo?]";
        
        const stats = parseStats(bonusStr);
        const asset = { name, type: 'item', stats, creator };
        
        // Persistência no Catálogo (Upsert baseado no nome único)
        const { error: assetError } = await supabase.from('created_assets').upsert(asset, { onConflict: 'name' });
        if (assetError) return `❌ Erro no catálogo: ${assetError.message}`;
        
        let response = `✅ Item "${name}" salvo no catálogo global.`;

        if (targetUser) {
          const target = await getTargetProfile(targetUser);
          if (target) {
            const newItem: Equipment = {
              id: crypto.randomUUID(),
              name,
              type: 'Arma' as ItemType,
              rarity: 'Mítico' as Rarity,
              stats,
              levelRequired: 1,
              description: `Artefato forjado por ${creator}.`
            };
            target.inventory.push(newItem);
            await supabase.from('profiles').upsert(target);
            if (target.username === user.username) onUpdateUser(target);
            response += ` Além disso, foi entregue a ${targetUser}.`;
          } else {
            response += ` ⚠️ Alvo "${targetUser}" não encontrado para entrega.`;
          }
        }
        return response;
      }

      case '/magia': {
        const [_, name, bonusStr, cost] = parts;
        if (!name || !bonusStr || !cost) return "Uso: /Magia [Nome] [multiplier:valor] [CustoMana]";
        
        const stats = parseStats(bonusStr);
        const asset = { name, type: 'magia', stats, creator: user.username, cost: parseInt(cost) };
        const { error: magiaError } = await supabase.from('created_assets').upsert(asset, { onConflict: 'name' });
        
        if (magiaError) return `❌ Erro arcano: ${magiaError.message}`;
        return `✅ Magia "${name}" agora reside no catálogo global.`;
      }

      case '/criação': {
        const { data: assets, error } = await supabase.from('created_assets').select('*');
        if (error) return `❌ Erro ao ler catálogo: ${error.message}`;
        if (!assets || assets.length === 0) return "📂 O catálogo global está vazio.";
        
        return `📂 CATÁLOGO DE ATIVOS:\n` + assets.map(a => {
          const statsStr = a.stats ? Object.entries(a.stats).map(([k,v]) => `${k}:${v}`).join(' ') : 'Sem status';
          return `- [${a.type.toUpperCase()}] ${a.name} | ${statsStr} | Criado por: ${a.creator}`;
        }).join('\n');
      }

      case '/remove': {
        const [_, name, targetUser] = parts;
        if (!name || !targetUser) return "Uso: /remove [Nome] [Usuário/global]";
        
        if (targetUser.toLowerCase() === 'global') {
          const { error } = await supabase.from('created_assets').delete().eq('name', name);
          if (error) return `❌ Erro ao deletar do catálogo: ${error.message}`;
          return `🗑️ "${name}" foi extinto do catálogo global.`;
        }
        
        const target = await getTargetProfile(targetUser);
        if (target) {
          const initialLen = target.inventory.length;
          target.inventory = target.inventory.filter(i => (i.name || '').toLowerCase() !== name.toLowerCase());
          if (target.inventory.length === initialLen) return `❌ ${targetUser} não possui este item.`;
          
          await supabase.from('profiles').upsert(target);
          if (target.username === user.username) onUpdateUser(target);
          return `🗑️ Item "${name}" removido do inventário de ${targetUser}.`;
        }
        return "❌ Alvo inválido.";
      }

      case '/give': {
        const [_, amountStr, targetUser, itemName] = parts;
        if (!amountStr || !targetUser || !itemName) return "Uso: /give [Qtd] [Usuário] [Item/XP/Gold]";
        
        const target = await getTargetProfile(targetUser);
        if (!target) return "❌ Caçador não encontrado.";
        const amount = parseInt(amountStr);
        const type = itemName.toLowerCase();

        if (type === 'gold' || type === 'ouro') target.gold += amount;
        else if (type === 'xp') {
          target.exp += amount;
          while (target.exp >= target.expToNext) {
            target.level += 1; target.statPoints += 8; target.exp -= target.expToNext;
            target.expToNext = calculateExpToNext(target.level); target.characterRank = getRankForLevel(target.level);
          }
        } else {
          // Busca no catálogo
          const { data: asset } = await supabase.from('created_assets').select('*').eq('name', itemName).single();
          if (asset) {
            for(let i=0; i < amount; i++) {
              target.inventory.push({
                id: crypto.randomUUID(),
                name: asset.name,
                type: (asset.type === 'magia' ? 'Amuleto' : 'Arma') as ItemType,
                rarity: 'Mítico',
                stats: asset.stats || {},
                levelRequired: 1,
                description: 'Concedido pelo catálogo divino.'
              });
            }
          } else return `❌ O ativo "${itemName}" não existe no catálogo.`;
        }

        target.totalPower = calculateTotalPower(target);
        await supabase.from('profiles').upsert(target);
        if (target.username === user.username) onUpdateUser(target);
        return `✅ Presente de ${amount}x ${itemName} entregue a ${targetUser}.`;
      }

      case '/elemento': {
        const [_, targetUser, newEl] = parts;
        if (!targetUser || !newEl) return "Uso: /elemento [Usuário] [Elemento]";
        
        const target = await getTargetProfile(targetUser);
        const elData = ELEMENTS.find(e => e.name.toLowerCase() === newEl.toLowerCase());
        
        if (target && elData) {
          target.element = elData.name as ElementType;
          target.skills = getBaseSkillsForElement(target.element); // Reset completo de magias
          await supabase.from('profiles').upsert(target);
          if (target.username === user.username) onUpdateUser(target);
          return `🌀 Transmutação completa: ${targetUser} agora domina ${elData.name} e suas artes.`;
        }
        return "❌ Falha na transmutação.";
      }

      case '/addmagia': {
        const [_, name, targetUser] = parts;
        const { data: asset } = await supabase.from('created_assets').select('*').eq('name', name).eq('type', 'magia').single();
        if (!asset) return `❌ Magia "${name}" não encontrada no catálogo.`;
        
        const target = await getTargetProfile(targetUser);
        if (target) {
          target.skills.push({
            id: crypto.randomUUID(),
            name: asset.name,
            description: "Conhecimento proibido do ADM.",
            minLevel: 1,
            minRank: CharacterRank.F,
            manaCost: asset.cost || 0,
            multiplier: (asset.stats && asset.stats.multiplier) || 1.5,
            isUnlocked: true
          });
          await supabase.from('profiles').upsert(target);
          if (target.username === user.username) onUpdateUser(target);
          return `✅ Conhecimento arcano de "${name}" transferido para ${targetUser}.`;
        }
        return "❌ Usuário não encontrado.";
      }

      case '/additem': {
        const [_, name, price] = parts;
        const { data: asset } = await supabase.from('created_assets').select('*').eq('name', name).single();
        if (asset) {
          await supabase.from('custom_shop').upsert({ name, price: parseInt(price), creator: asset.creator, asset_ref: asset.id }, { onConflict: 'name' });
          return `🛒 "${name}" adicionado ao Mercado por ${price} Gold.`;
        }
        return "❌ Item não existe no catálogo.";
      }

      default: return "❌ Comando ADM desconhecido. Use /help.";
    }
  };

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    const content = input.trim();
    setInput('');

    if (content.startsWith('/')) {
      const response = await executeCommand(content);
      const sysMsg: ChatMessage = {
        id: 'sys-' + Date.now(),
        sender: "SISTEMA",
        content: response,
        timestamp: Date.now(),
        isAdmin: false,
        channel: activeChatTab
      };
      if (activeChatTab === 'global') setMessages(prev => [...prev, sysMsg]);
      else setStaffMessages(prev => [...prev, sysMsg]);
      return;
    }

    const newMessage = {
      id: crypto.randomUUID(),
      sender: user.username,
      content,
      timestamp: Date.now(),
      isAdmin,
      channel: activeChatTab
    };
    await supabase.from('chat_messages').insert(newMessage);
  };

  return (
    <div className="flex flex-col h-[600px] rpg-card rounded-3xl overflow-hidden shadow-2xl border border-slate-800">
      <div className="p-3 bg-slate-900 border-b border-slate-800 flex justify-between items-center">
        <div className="flex gap-2">
          <button onClick={() => setActiveChatTab('global')} className={`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase ${activeChatTab === 'global' ? 'bg-indigo-600 shadow-lg shadow-indigo-900/40' : 'bg-slate-800 text-slate-500'}`}>Global</button>
          {isAdmin && <button onClick={() => setActiveChatTab('staff')} className={`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase ${activeChatTab === 'staff' ? 'bg-red-600 shadow-lg shadow-red-900/40' : 'bg-slate-800 text-slate-500'}`}>Staff</button>}
        </div>
        <div className="text-[9px] font-black text-slate-600 uppercase tracking-widest">Torre dos Caçadores</div>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-950/40 custom-scrollbar">
        {(activeChatTab === 'global' ? messages : staffMessages).map((msg) => (
          <div key={msg.id} className={`flex flex-col ${msg.sender === user.username ? 'items-end' : 'items-start'} animate-in slide-in-from-bottom-1`}>
            <div className="flex items-center gap-2 mb-1">
               {msg.isAdmin && <span className="bg-red-600 text-[7px] px-1 py-0.5 rounded text-white font-black">ADM</span>}
               <span className={`text-[9px] font-black uppercase ${msg.sender === 'SISTEMA' ? 'text-amber-500' : 'text-indigo-400'}`}>{msg.sender}</span>
            </div>
            <div className={`max-w-[85%] px-4 py-3 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap ${msg.sender === 'SISTEMA' ? 'bg-amber-900/10 text-amber-200 border border-amber-500/20 italic' : (msg.sender === user.username ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-200 border border-slate-700')}`}>
              {msg.content}
            </div>
          </div>
        ))}
        <div ref={chatEndRef} />
      </div>

      <form onSubmit={sendMessage} className="p-4 bg-slate-900 border-t border-slate-800 flex gap-3">
        <input 
          type="text" 
          value={input} 
          onChange={(e) => setInput(e.target.value)} 
          placeholder={isAdmin ? "Comando ou Mensagem..." : "Mande uma mensagem..."}
          className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-4 py-2 text-sm focus:outline-none focus:border-indigo-500 placeholder-slate-600" 
        />
        <button type="submit" className="bg-indigo-600 hover:bg-indigo-500 px-6 py-2 rounded-xl font-black text-[10px] uppercase shadow-lg transition-all active:scale-95">Enviar</button>
      </form>
    </div>
  );
};

export default GlobalChat;
