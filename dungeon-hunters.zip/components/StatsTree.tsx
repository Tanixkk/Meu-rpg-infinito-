
import React from 'react';
import { UserProfile, Stats } from '../types';

interface StatsTreeProps {
  user: UserProfile;
  onUpdateUser: (updated: UserProfile) => void;
}

const StatsTree: React.FC<StatsTreeProps> = ({ user, onUpdateUser }) => {
  const upgradeStat = (statName: keyof Stats) => {
    if (user.statPoints <= 0) return;

    const newUser = { ...user };
    newUser.statPoints -= 1;
    
    if (statName === 'hp') newUser.stats.hp += 20;
    else if (statName === 'strength') newUser.stats.strength += 3;
    else if (statName === 'mana') newUser.stats.mana += 15;
    else if (statName === 'elementalDamage') newUser.stats.elementalDamage += 4;
    else if (statName === 'defense') newUser.stats.defense += 2;
    else if (statName === 'magicDefense') newUser.stats.magicDefense += 2;
    else if (statName === 'critChance') newUser.stats.critChance += 1;
    else if (statName === 'critDamage') newUser.stats.critDamage += 5;

    onUpdateUser(newUser);
  };

  const statConfig = [
    { key: 'hp', label: 'Vida', color: 'text-red-500', icon: '❤️', desc: '+20 HP por ponto.' },
    { key: 'strength', label: 'Força', color: 'text-orange-500', icon: '💪', desc: '+3 Força por ponto.' },
    { key: 'mana', label: 'Mana', color: 'text-blue-500', icon: '🧪', desc: '+15 Mana por ponto.' },
    { key: 'elementalDamage', label: 'Dano Elemental', color: 'text-cyan-500', icon: '✨', desc: '+4 Dano Magico por ponto.' },
    { key: 'defense', label: 'Defesa Física', color: 'text-slate-400', icon: '🛡️', desc: '+2 Defesa por ponto.' },
    { key: 'magicDefense', label: 'Defesa Mágica', color: 'text-purple-400', icon: '🔮', desc: '+2 Def. Mag por ponto.' },
    { key: 'critChance', label: 'Chance Crítico', color: 'text-yellow-500', icon: '🎯', desc: '+1% Crit por ponto.' },
    { key: 'critDamage', label: 'Dano Crítico', color: 'text-red-700', icon: '💥', desc: '+5% Dmg Crit por ponto.' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-fantasy font-black">Árvore de Atributos</h2>
          <p className="text-slate-400">Personalize o poder do seu caçador</p>
        </div>
        <div className="bg-indigo-600 px-8 py-4 rounded-2xl shadow-xl shadow-indigo-900/40 flex flex-col items-center">
          <span className="text-[10px] uppercase font-black text-indigo-200">Pontos</span>
          <span className="text-3xl font-black">{user.statPoints}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {statConfig.map((s) => (
          <div key={s.key} className="rpg-card rounded-2xl p-4 border-l-4 border-slate-800 hover:border-indigo-500 transition-all flex flex-col justify-between h-44">
            <div>
              <div className="flex justify-between items-start mb-2">
                <span className="text-2xl">{s.icon}</span>
                <span className="text-xl font-black">{user.stats[s.key as keyof Stats]}</span>
              </div>
              <h3 className={`font-bold text-sm ${s.color}`}>{s.label}</h3>
              <p className="text-[9px] text-slate-500 italic mt-1">{s.desc}</p>
            </div>
            
            <button
              disabled={user.statPoints <= 0}
              onClick={() => upgradeStat(s.key as keyof Stats)}
              className="mt-4 py-2 bg-slate-800 hover:bg-indigo-600 disabled:opacity-20 rounded-lg font-black text-[10px] transition-all"
            >
              TREINAR
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default StatsTree;
