
import React, { useState, useEffect } from 'react';
import { UserProfile, Monster, DamageEffect, Skill, Mission } from '../types';
import { generateMonster, calculateBattleAction, calculateExpToNext, getRankForLevel, getEffectiveStats, calculateTotalPower } from '../services/gameEngine';

interface TowerMapProps {
  user: UserProfile;
  onUpdateUser: (updated: UserProfile) => void;
}

const TowerMap: React.FC<TowerMapProps> = ({ user, onUpdateUser }) => {
  const [currentMonster, setCurrentMonster] = useState<Monster | null>(null);
  const [isFighting, setIsFighting] = useState(false);
  const [battleLog, setBattleLog] = useState<string[]>([]);
  const [effects, setEffects] = useState<DamageEffect[]>([]);
  const [combatMenu, setCombatMenu] = useState<'main' | 'player_skills'>('main');
  
  const stats = getEffectiveStats(user);
  const [playerHp, setPlayerHp] = useState(stats.hp);
  const [playerMana, setPlayerMana] = useState(stats.mana);

  useEffect(() => {
    setCurrentMonster(generateMonster(user.currentFloor));
    setPlayerHp(stats.hp);
    setPlayerMana(stats.mana);
    setBattleLog([`Você entrou no Andar ${user.currentFloor}.`]);
  }, [user.currentFloor]);

  const changeFloor = (delta: number) => {
    if (isFighting) return;
    const nextFloor = user.currentFloor + delta;
    if (nextFloor >= 1 && nextFloor <= user.maxFloorReached + 1) {
      onUpdateUser({ ...user, currentFloor: nextFloor });
    }
  };

  const handleBattleAction = (skill?: Skill) => {
    if (!currentMonster || isFighting || playerHp <= 0) return;
    
    if (skill && playerMana < skill.manaCost) {
      setBattleLog(prev => [`Mana insuficiente para ${skill.name}!`, ...prev]);
      return;
    }

    setIsFighting(true);
    const result = calculateBattleAction(user, currentMonster, skill);
    
    let dmgType: 'physical' | 'elemental' | 'crit' | 'pet' = result.isCrit ? 'crit' : (skill ? 'elemental' : 'physical');
    addEffect(result.damageDealt, dmgType);
    
    setTimeout(() => addEffect(result.damageTaken, 'monster'), 400);

    const newMonsterHp = Math.max(0, currentMonster.hp - result.damageDealt);
    const newPlayerHp = Math.max(0, playerHp - result.damageTaken);
    const newPlayerMana = playerMana - result.manaSpent;

    setPlayerHp(newPlayerHp);
    setPlayerMana(newPlayerMana);
    setCurrentMonster({ ...currentMonster, hp: newMonsterHp });

    if (newMonsterHp <= 0) {
      handleWin();
    } else if (newPlayerHp <= 0) {
      handleLoss();
    } else {
      setTimeout(() => {
        setIsFighting(false);
        setCombatMenu('main');
      }, 600);
    }
  };

  const handleWin = () => {
    const expGained = Math.floor(40 * Math.pow(1.15, user.currentFloor));
    const goldGained = Math.floor(20 * Math.pow(1.08, user.currentFloor));
    
    let newUser = { ...user };
    newUser.exp += expGained;
    newUser.gold += goldGained;
    newUser.stats.mana = Math.min(newUser.stats.mana + 15, stats.mana);

    if (currentMonster?.type === 'Boss') newUser.bossKills += 1;
    else newUser.monsterKills += 1;

    // Lógica de Missões e Drops
    const missionMessages: string[] = [];
    newUser.missions = newUser.missions.map(mission => {
      if (mission.isCompleted) return mission;

      let updated = false;
      const onCorrectFloor = !mission.floorRange || (newUser.currentFloor >= mission.floorRange[0] && newUser.currentFloor <= mission.floorRange[1]);

      if (mission.type === 'kill' && onCorrectFloor) {
        mission.current += 1;
        updated = true;
      } else if (mission.type === 'collect' && onCorrectFloor) {
        // Chance de 60% de dropar o item da missão
        if (Math.random() < 0.6) {
          mission.current += 1;
          updated = true;
          missionMessages.push(`💎 Drop de Missão: ${mission.targetItemId} coletado!`);
        }
      } else if (mission.type === 'escort' && newUser.currentFloor >= mission.target) {
        mission.current = mission.target;
        updated = true;
      }

      if (updated && mission.current >= mission.target) {
        mission.isCompleted = true;
        newUser.exp += mission.rewardExp;
        newUser.gold += mission.rewardGold;
        missionMessages.push(`✅ MISSÃO CONCLUÍDA: ${mission.title}! Recompensas entregues.`);
      }

      return mission;
    });

    // Remove as missões concluídas automaticamente para abrir espaço
    newUser.missions = newUser.missions.filter(m => !m.isCompleted);

    if (user.currentFloor === user.maxFloorReached + 1 || user.currentFloor === user.maxFloorReached) {
      newUser.maxFloorReached = Math.max(newUser.maxFloorReached, user.currentFloor);
    }

    while (newUser.exp >= newUser.expToNext) {
      newUser.level += 1;
      newUser.statPoints += 8;
      newUser.exp -= newUser.expToNext;
      newUser.expToNext = calculateExpToNext(newUser.level);
      newUser.characterRank = getRankForLevel(newUser.level);
      missionMessages.push(`🌟 LEVEL UP! Você alcançou o Nível ${newUser.level}!`);
    }

    newUser.totalPower = calculateTotalPower(newUser);
    onUpdateUser(newUser);
    
    setBattleLog(prev => [
      `Vitória! +${expGained} XP, +${goldGained} Gold`,
      ...missionMessages,
      ...prev
    ]);
    setIsFighting(false);
    setCurrentMonster(generateMonster(user.currentFloor));
  };

  const handleLoss = () => {
    setBattleLog(prev => [`Você caiu em batalha... Expulso da torre.`, ...prev]);
    const newUser = { ...user, deaths: user.deaths + 1, currentFloor: Math.max(1, user.currentFloor - 2) };
    onUpdateUser(newUser);
    setIsFighting(false);
  };

  const addEffect = (value: number, type: 'physical' | 'elemental' | 'monster' | 'crit' | 'pet') => {
    const id = Date.now() + Math.random();
    setEffects(prev => [...prev, { id, value, type, x: Math.random() * 120 - 60, y: Math.random() * -80 - 40 }]);
    setTimeout(() => setEffects(prev => prev.filter(e => e.id !== id)), 1200);
  };

  return (
    <div className="space-y-6 relative min-h-[600px]">
      <div className="absolute inset-0 pointer-events-none z-50 overflow-hidden">
        {effects.map(eff => (
          <div key={eff.id} className={`absolute left-1/2 top-1/2 font-black italic animate-bounce-out ${
              eff.type === 'physical' ? 'text-white text-3xl' : 
              eff.type === 'elemental' ? 'text-cyan-400 text-3xl' : 
              eff.type === 'pet' ? 'text-emerald-400 text-3xl' :
              eff.type === 'crit' ? 'text-yellow-400 text-5xl scale-125 glowing-text' : 
              'text-red-600 text-3xl'
            }`} style={{ transform: `translate(${eff.x}px, ${eff.y}px)`, textShadow: '2px 2px 8px rgba(0,0,0,0.8)' }}>
            {eff.type === 'crit' ? '💥 ' : ''}{eff.value}
          </div>
        ))}
      </div>

      <div className="flex flex-col md:flex-row justify-between items-center bg-slate-900/50 p-6 rounded-[2rem] border border-slate-800 shadow-xl">
        <div className="flex items-center gap-6">
          <button onClick={() => changeFloor(-1)} disabled={user.currentFloor <= 1 || isFighting} className="bg-slate-800 p-4 rounded-full hover:bg-indigo-600 disabled:opacity-20 transition-all border border-slate-700 active:scale-90">◀</button>
          <div className="text-center">
            <h2 className="text-4xl font-fantasy font-black glowing-text text-white uppercase tracking-tighter">Andar {user.currentFloor}</h2>
            <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Exploração Ativa</p>
          </div>
          <button onClick={() => changeFloor(1)} disabled={user.currentFloor > user.maxFloorReached || isFighting} className="bg-slate-800 p-4 rounded-full hover:bg-indigo-600 disabled:opacity-20 transition-all border border-slate-700 active:scale-90">▶</button>
        </div>
        
        <div className="flex gap-4">
           <div className="px-6 py-3 bg-slate-950/80 rounded-2xl border border-red-900/30 text-center min-w-[120px] shadow-lg">
              <span className="text-[9px] font-black text-red-500 uppercase block tracking-widest">Integridade</span>
              <p className="text-xl font-bold text-red-200">{playerHp}</p>
           </div>
           <div className="px-6 py-3 bg-slate-950/80 rounded-2xl border border-blue-900/30 text-center min-w-[120px] shadow-lg">
              <span className="text-[9px] font-black text-blue-500 uppercase block tracking-widest">Energia</span>
              <p className="text-xl font-bold text-blue-200">{playerMana}</p>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        <div className="rpg-card rounded-[2.5rem] p-10 flex flex-col items-center text-center relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-indigo-500 to-transparent"></div>
          {currentMonster ? (
            <>
              {currentMonster.lore && (
                <div className="mb-6 bg-indigo-900/20 p-4 rounded-2xl border border-indigo-500/30 animate-in fade-in max-w-sm">
                  <p className="text-[11px] italic text-indigo-300 leading-relaxed">"{currentMonster.lore}"</p>
                </div>
              )}
              <span className={`px-4 py-1.5 rounded-full text-[9px] font-black mb-4 uppercase tracking-[0.2em] ${currentMonster.type === 'Boss' ? 'bg-red-600 shadow-lg shadow-red-900/40' : 'bg-slate-800 text-slate-400'}`}>
                {currentMonster.type} - NVL {currentMonster.level}
              </span>
              <h3 className="text-3xl font-fantasy font-black mb-8 text-white tracking-wide">{currentMonster.name}</h3>
              <div className="w-full max-w-sm mb-12 relative">
                <div className="absolute -inset-2 bg-indigo-500/20 blur-2xl rounded-full group-hover:bg-indigo-500/30 transition-all"></div>
                <img src={currentMonster.image} className="w-full aspect-square object-cover rounded-[2rem] border-4 border-slate-800 shadow-2xl relative z-10" />
                <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 w-[80%] z-20">
                   <div className="h-5 bg-slate-950 rounded-full overflow-hidden border-2 border-slate-800 shadow-xl">
                      <div className="h-full bg-gradient-to-r from-red-600 to-orange-500 transition-all duration-500" style={{ width: `${(currentMonster.hp/currentMonster.maxHp)*100}%` }}></div>
                   </div>
                   <div className="flex justify-between mt-1 px-2">
                      <span className="text-[8px] font-black text-slate-500">HP MONSTRO</span>
                      <span className="text-[8px] font-black text-slate-500">{currentMonster.hp} / {currentMonster.maxHp}</span>
                   </div>
                </div>
              </div>

              <div className="w-full flex flex-col gap-4 mt-6">
                {combatMenu === 'main' && (
                  <div className="grid grid-cols-2 gap-4">
                    <button onClick={() => handleBattleAction()} disabled={isFighting} className="bg-slate-800 hover:bg-slate-700 py-4 rounded-2xl font-black uppercase text-xs tracking-widest border border-slate-700 transition-all active:scale-95">⚔️ Ataque Físico</button>
                    <button onClick={() => setCombatMenu('player_skills')} disabled={isFighting} className="bg-indigo-600 hover:bg-indigo-500 py-4 rounded-2xl font-black uppercase text-xs tracking-widest shadow-lg shadow-indigo-900/40 transition-all active:scale-95">🪄 Artes Arcanas</button>
                  </div>
                )}
                {combatMenu === 'player_skills' && (
                  <div className="space-y-3 animate-in slide-in-from-right duration-300">
                    <button onClick={() => setCombatMenu('main')} className="text-[9px] text-indigo-400 hover:text-white uppercase font-black tracking-widest mb-2 flex items-center gap-2"><span>⬅</span> VOLTAR AO MENU</button>
                    <div className="grid grid-cols-1 gap-2 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
                      {user.skills.filter(s => s.isUnlocked).map(skill => (
                        <button 
                          key={skill.id} 
                          onClick={() => handleBattleAction(skill)}
                          className="w-full bg-slate-900 hover:bg-indigo-950 p-4 rounded-2xl flex justify-between items-center border border-slate-800 group/skill transition-all hover:border-indigo-500/50"
                        >
                          <div className="text-left">
                            <span className="font-black text-[11px] block text-white group-hover/skill:text-indigo-400 uppercase tracking-tighter">{skill.name}</span>
                            <span className="text-[9px] text-slate-500 font-bold uppercase">Mult: x{skill.multiplier}</span>
                          </div>
                          <div className="flex items-center gap-2">
                             <span className="text-[10px] font-black text-blue-400">{skill.manaCost} MP</span>
                             <span className="text-xl">🪄</span>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </>
          ) : <p className="py-20 animate-pulse uppercase font-black text-slate-600 tracking-[0.5em]">Escaneando Presenças...</p>}
        </div>

        <div className="rpg-card rounded-[2.5rem] p-8 h-[600px] overflow-hidden flex flex-col bg-black/40 border border-slate-800">
           <div className="flex justify-between items-center border-b border-slate-800 pb-4 mb-4">
              <h4 className="font-black text-slate-500 uppercase tracking-widest text-xs">Registros de Batalha</h4>
              <div className="flex gap-2">
                 <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"></span>
                 <span className="text-[9px] text-slate-600 uppercase font-black">Link Neural Ativo</span>
              </div>
           </div>
           <div className="flex-1 overflow-y-auto space-y-3 custom-scrollbar">
             {battleLog.map((l, i) => (
               <div key={i} className={`p-4 rounded-2xl text-[11px] font-mono leading-relaxed transition-all ${
                 i === 0 
                  ? "bg-indigo-600/10 text-white font-bold border border-indigo-500/30 translate-x-1" 
                  : "text-slate-500 border border-transparent"
               }`}>
                 <span className="opacity-30 mr-2">[{new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}]</span>
                 {l}
               </div>
             ))}
           </div>
        </div>
      </div>
    </div>
  );
};

export default TowerMap;
