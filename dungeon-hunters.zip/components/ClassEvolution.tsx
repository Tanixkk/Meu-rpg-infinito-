
import React from 'react';
import { UserProfile, ClassData } from '../types';

interface ClassEvolutionProps {
  user: UserProfile;
  options: ClassData[];
  onSelect: (chosen: ClassData) => void;
}

const ClassEvolution: React.FC<ClassEvolutionProps> = ({ user, options, onSelect }) => {
  const isRelic = user.evolutionStage === 1;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/95 backdrop-blur-2xl p-6 overflow-y-auto">
      <div className="max-w-6xl w-full flex flex-col items-center py-12">
        <div className="text-center mb-16 animate-in slide-in-from-top duration-700">
          <h2 className={`text-6xl md:text-8xl font-fantasy font-black mb-4 ${isRelic ? 'text-yellow-400 shadow-yellow-500/20' : 'text-indigo-400 shadow-indigo-500/20'} drop-shadow-2xl uppercase tracking-tighter`}>
            {isRelic ? 'Ascensão Relíquia' : 'Despertar de Classe'}
          </h2>
          <div className="flex items-center justify-center gap-4">
            <div className="h-px w-24 bg-gradient-to-r from-transparent to-slate-500"></div>
            <p className="text-slate-400 font-bold uppercase tracking-[0.3em] text-sm">Escolha seu Destino Eterno</p>
            <div className="h-px w-24 bg-gradient-to-l from-transparent to-slate-500"></div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 w-full">
          {options.map((opt, idx) => (
            <div 
              key={idx} 
              className={`rpg-card rounded-[2.5rem] p-10 border-2 transition-all group flex flex-col justify-between relative overflow-hidden h-[600px] ${
                isRelic 
                  ? 'border-yellow-500/30 hover:border-yellow-400 shadow-2xl hover:shadow-yellow-500/10' 
                  : 'border-indigo-500/30 hover:border-indigo-400 shadow-2xl hover:shadow-indigo-500/10'
              }`}
            >
              <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-white/5 to-transparent -rotate-45 translate-x-32 -translate-y-32"></div>
              
              <div className="relative z-10">
                <div className="flex justify-between items-start mb-8">
                   <div className={`text-[10px] font-black px-4 py-1.5 rounded-full border uppercase tracking-widest ${isRelic ? 'border-yellow-500 text-yellow-500 bg-yellow-500/10' : 'border-indigo-500 text-indigo-500 bg-indigo-500/10'}`}>
                      Caminho {idx + 1}
                   </div>
                   <span className="text-4xl opacity-20 group-hover:opacity-100 transition-opacity">
                      {isRelic ? '💎' : '🔥'}
                   </span>
                </div>

                <h3 className={`text-5xl font-fantasy font-black mb-6 transition-all group-hover:tracking-wider ${isRelic ? 'text-white' : 'text-white'}`}>
                  {opt.name}
                </h3>
                
                <p className="text-slate-400 mb-10 text-lg leading-relaxed italic">
                  "{opt.description}"
                </p>

                <div className="space-y-4 mb-8">
                  <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Bônus de Atributos</h4>
                  <div className="grid grid-cols-2 gap-4">
                    {Object.entries(opt.bonuses).map(([stat, val]) => (
                      <div key={stat} className="bg-slate-900/80 rounded-2xl p-4 border border-slate-800 group-hover:border-slate-700 transition-all">
                        <p className="text-[9px] text-slate-500 uppercase font-black mb-1">{stat}</p>
                        <p className="text-2xl font-black text-green-400">+{val}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <button 
                onClick={() => onSelect(opt)}
                className={`w-full py-6 rounded-3xl font-black text-2xl transition-all shadow-2xl relative overflow-hidden active:scale-95 ${
                  isRelic 
                    ? 'bg-yellow-600 hover:bg-yellow-500 text-slate-950 shadow-yellow-900/40' 
                    : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-900/40'
                }`}
              >
                REIVINDICAR PODER
              </button>
            </div>
          ))}
        </div>

        <div className="mt-16 text-slate-600 text-[10px] font-black uppercase tracking-[0.5em] animate-pulse">
           O poder uma vez escolhido, torna-se sua alma
        </div>
      </div>
    </div>
  );
};

export default ClassEvolution;
