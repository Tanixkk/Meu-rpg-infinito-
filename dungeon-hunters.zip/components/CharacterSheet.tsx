
import React, { useEffect, useState } from 'react';
import { UserProfile, PetTier } from '../types';
import { getEvolutionStageName, getRankColor } from '../services/gameEngine';
import { supabase } from '../supabase';

interface CharacterSheetProps {
  playerId: string;
  onBack: () => void;
}

const CharacterSheet: React.FC<CharacterSheetProps> = ({ playerId, onBack }) => {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProfile = async () => {
      const { data } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', playerId)
        .single();
      if (data) setProfile(data as UserProfile);
      setLoading(false);
    };
    fetchProfile();
  }, [playerId]);

  if (loading) return <div className="p-12 text-center text-slate-500">Buscando ficha...</div>;
  if (!profile) return null;

  const tierColors: Record<PetTier, string> = {
    'Comum': 'text-slate-400', 'Incomum': 'text-green-400', 'Raro': 'text-blue-400', 'Muito Raro': 'text-purple-400',
    'Épico': 'text-pink-400', 'Épico+': 'text-pink-600', 'Lendário': 'text-orange-400', 'Místico': 'text-red-400', 'Relíquia': 'text-yellow-400 glowing-text'
  };

  return (
    <div className="space-y-8 animate-in zoom-in duration-300">
      <button onClick={onBack} className="bg-slate-800 px-6 py-2 rounded-xl text-xs font-black">VOLTAR</button>
      
      <div 
        className="rpg-card rounded-3xl p-8 flex flex-col lg:flex-row gap-12 relative overflow-hidden min-h-[500px]"
        style={profile.backgroundPhoto ? { 
          backgroundImage: `linear-gradient(rgba(15, 23, 42, 0.8), rgba(15, 23, 42, 0.95)), url(${profile.backgroundPhoto})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        } : {}}
      >
        <div className="flex flex-col items-center min-w-[300px] z-10">
           <img src={profile.avatar} className="w-64 h-64 rounded-3xl border-4 border-indigo-500 shadow-2xl mb-6 object-cover bg-slate-900" />
           <h2 className="text-4xl font-fantasy font-black text-white drop-shadow-lg">{profile.username}</h2>
           <p className="text-indigo-400 font-bold uppercase tracking-widest text-sm">{profile.currentTitle?.name || 'Sem Título'}</p>
           <div className="mt-2 text-center">
              <span className="text-xs font-black text-slate-300 uppercase px-4 py-1 bg-slate-800/50 rounded-full border border-slate-700">
                 {profile.class} - {getEvolutionStageName(profile.evolutionStage)}
              </span>
           </div>
           
           {profile.pet && (
             <div className="mt-8 bg-black/60 p-6 rounded-2xl border border-indigo-500/30 backdrop-blur-md w-full flex flex-col items-center">
                <span className="text-[10px] font-black text-slate-500 uppercase mb-4 tracking-tighter">Companheiro Elemental</span>
                <div className="w-20 h-20 rounded-xl overflow-hidden mb-3 border-2 border-slate-700">
                   {profile.pet.image ? (
                     <img src={profile.pet.image} className="w-full h-full object-cover" />
                   ) : (
                     <div className="w-full h-full flex items-center justify-center text-3xl bg-slate-800">🐾</div>
                   )}
                </div>
                <h4 className="font-fantasy font-bold text-white text-lg">{profile.pet.name}</h4>
                <p className={`text-[10px] font-black uppercase ${tierColors[profile.pet.tier]}`}>{profile.pet.tier} - NVL {profile.pet.level}</p>
             </div>
           )}
        </div>

        <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-8 z-10">
           <div className="space-y-4">
              <h3 className="text-xs font-black text-slate-300 uppercase border-b border-slate-700 pb-2">Informações Base</h3>
              <div className="grid grid-cols-2 gap-4">
                 <div className="bg-slate-900/70 p-4 rounded-xl border border-slate-700 backdrop-blur-sm">
                    <span className="text-[9px] font-black text-slate-500 block">ELEMENTO</span>
                    <span className="font-bold text-sm text-cyan-400">{profile.element}</span>
                 </div>
                 <div className="bg-slate-900/70 p-4 rounded-xl border border-slate-700 backdrop-blur-sm">
                    <span className="text-[9px] font-black text-slate-500 block">RANK</span>
                    <span className={`font-bold text-sm uppercase ${getRankColor(profile.characterRank)}`}>{profile.characterRank}</span>
                 </div>
                 <div className="bg-slate-900/70 p-4 rounded-xl border border-slate-700 backdrop-blur-sm">
                    <span className="text-[9px] font-black text-slate-500 block">NÍVEL</span>
                    <span className="font-bold text-sm">{profile.level}</span>
                 </div>
                 <div className="bg-slate-900/70 p-4 rounded-xl border border-slate-700 backdrop-blur-sm">
                    <span className="text-[9px] font-black text-slate-500 block">PODER</span>
                    <span className="font-bold text-sm text-yellow-500">{profile.totalPower} ⚡</span>
                 </div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default CharacterSheet;
