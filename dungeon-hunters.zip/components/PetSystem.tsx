
import React, { useState } from 'react';
import { UserProfile, Pet, PetTier } from '../types';
import { generateAIPet, calculateTotalPower, canEvolvePet, evolvePet, getPetEvolveRequirements, getNextPetTier } from '../services/gameEngine';

interface PetSystemProps {
  user: UserProfile;
  onUpdateUser: (updated: UserProfile) => void;
}

const PetSystem: React.FC<PetSystemProps> = ({ user, onUpdateUser }) => {
  const [rolling, setRolling] = useState(false);
  const [activeTab, setActiveTab] = useState<'status' | 'skills' | 'evolve' | 'custom'>('status');
  const [newName, setNewName] = useState(user.pet?.name || '');

  const rollPet = async () => {
    if (user.gold < 1000) return alert("Precisa de 1000 Ouro!");
    setRolling(true);
    
    const rand = Math.random() * 100;
    let tier: PetTier = 'Comum';
    if (rand < 1) tier = 'Relíquia';
    else if (rand < 5) tier = 'Místico';
    else if (rand < 12) tier = 'Lendário';
    else if (rand < 25) tier = 'Épico+';
    else if (rand < 40) tier = 'Épico';
    else if (rand < 60) tier = 'Muito Raro';
    else if (rand < 80) tier = 'Raro';
    else tier = 'Incomum';

    const newPet = await generateAIPet(user.element, tier);
    const newUser = { ...user, pet: newPet, gold: user.gold - 1000 };
    newUser.totalPower = calculateTotalPower(newUser);
    onUpdateUser(newUser);
    setRolling(false);
  };

  const addStat = (statName: keyof Pet['stats']) => {
    if (!user.pet || user.pet.statPoints <= 0) return;
    const newUser = { ...user };
    newUser.pet!.stats[statName] += 5;
    newUser.pet!.statPoints -= 1;
    newUser.totalPower = calculateTotalPower(newUser);
    onUpdateUser(newUser);
  };

  const handleEvolution = () => {
    if (!user.pet) return;
    if (!canEvolvePet(user)) {
      alert("Você não possui os requisitos necessários (Frags, Ouro ou Nível)!");
      return;
    }
    const newUser = evolvePet(user);
    onUpdateUser(newUser);
    alert(`Seu pet evoluiu para o rank ${newUser.pet!.tier}!`);
  };

  const handlePetPhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && user.pet) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const newUser = { ...user };
        newUser.pet!.image = reader.result as string;
        onUpdateUser(newUser);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRename = () => {
    if (!newName.trim() || !user.pet) return;
    const newUser = { ...user };
    newUser.pet!.name = newName;
    onUpdateUser(newUser);
    alert("Companheiro renomeado!");
  };

  if (!user.pet) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <h2 className="text-4xl font-fantasy font-black glowing-text mb-6">Despertar Companheiro Elemental</h2>
        <div className="rpg-card p-12 rounded-3xl max-w-lg">
           <p className="text-slate-400 mb-8 italic">Pets elementais auxiliam no combate e aumentam o seu poder total drasticamente. Gaste ouro para invocar um.</p>
           <button 
             onClick={rollPet} 
             disabled={rolling}
             className="bg-indigo-600 px-12 py-4 rounded-full font-black text-xl hover:bg-indigo-500 shadow-2xl transition-all"
           >
             {rolling ? 'INVOCANDO...' : 'INVOCAR PET (1000 Ouro)'}
           </button>
        </div>
      </div>
    );
  }

  const tierColors: Record<PetTier, string> = {
    'Comum': 'text-slate-400', 'Incomum': 'text-green-400', 'Raro': 'text-blue-400', 'Muito Raro': 'text-purple-400',
    'Épico': 'text-pink-400', 'Épico+': 'text-pink-600', 'Lendário': 'text-orange-400', 'Místico': 'text-red-400', 'Relíquia': 'text-yellow-400 glowing-text'
  };

  const nextTier = getNextPetTier(user.pet.tier);
  const evolveReq = getPetEvolveRequirements(user.pet.tier);

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div>
          <h2 className="text-4xl font-fantasy font-black glowing-text">{user.pet.name}</h2>
          <p className={`font-black uppercase tracking-widest text-sm ${tierColors[user.pet.tier]}`}>{user.pet.tier} - NVL {user.pet.level}</p>
        </div>
        <div className="flex gap-2 flex-wrap">
           <button onClick={() => setActiveTab('status')} className={`px-4 py-2 rounded-lg font-black text-xs ${activeTab === 'status' ? 'bg-indigo-600' : 'bg-slate-800'}`}>STATUS</button>
           <button onClick={() => setActiveTab('skills')} className={`px-4 py-2 rounded-lg font-black text-xs ${activeTab === 'skills' ? 'bg-indigo-600' : 'bg-slate-800'}`}>MAGIAS</button>
           <button onClick={() => setActiveTab('evolve')} className={`px-4 py-2 rounded-lg font-black text-xs ${activeTab === 'evolve' ? 'bg-indigo-600' : 'bg-slate-800'}`}>EVOLUÇÃO</button>
           <button onClick={() => setActiveTab('custom')} className={`px-4 py-2 rounded-lg font-black text-xs ${activeTab === 'custom' ? 'bg-indigo-600' : 'bg-slate-800'}`}>PERSONALIZAR</button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-5 rpg-card rounded-3xl p-8 flex flex-col items-center">
           <div className="w-64 h-64 bg-slate-900 rounded-full border-4 border-indigo-500/50 flex items-center justify-center text-8xl shadow-2xl mb-8 overflow-hidden">
              {user.pet.image ? <img src={user.pet.image} className="w-full h-full object-cover" /> : '🐾'}
           </div>
           <div className="w-full space-y-4">
              <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                 <div className="h-full bg-indigo-500" style={{ width: `${(user.pet.exp / (user.pet.level * 100)) * 100}%` }}></div>
              </div>
              <p className="text-center text-[10px] font-black uppercase text-slate-500">Experiência: {user.pet.exp} / {user.pet.level * 100}</p>
              
              <div className="grid grid-cols-2 gap-2">
                 <div className="bg-indigo-900/30 px-4 py-2 rounded-xl border border-indigo-500/30 text-center">
                    <span className="text-[10px] font-black uppercase text-indigo-400">Pontos Pet</span>
                    <p className="text-xl font-black">{user.pet.statPoints}</p>
                 </div>
                 <div className="bg-emerald-900/30 px-4 py-2 rounded-xl border border-emerald-500/30 text-center">
                    <span className="text-[10px] font-black uppercase text-emerald-400">Fragmentos</span>
                    <p className="text-xl font-black">{user.petFragments}</p>
                 </div>
              </div>
           </div>
        </div>

        <div className="lg:col-span-7 space-y-4">
           {activeTab === 'status' && (
             <div className="space-y-4 animate-in fade-in">
                {Object.entries(user.pet.stats).map(([k, v]) => (
                  <div key={k} className="rpg-card p-4 rounded-xl flex justify-between items-center border-l-4 border-indigo-500">
                      <div>
                        <span className="text-[10px] font-black uppercase text-slate-500">{k}</span>
                        <p className="text-xl font-bold">{v}</p>
                      </div>
                      <button 
                        onClick={() => addStat(k as any)}
                        disabled={user.pet!.statPoints <= 0}
                        className="bg-indigo-600 px-4 py-2 rounded-lg font-black hover:bg-indigo-500 disabled:opacity-20"
                      >
                        +
                      </button>
                  </div>
                ))}
             </div>
           )}

           {activeTab === 'skills' && (
             <div className="space-y-3 animate-in fade-in">
                <h3 className="text-xs font-black text-slate-500 uppercase mb-4">Grimório do Pet</h3>
                {user.pet.skills.map(skill => (
                  <div key={skill.id} className="rpg-card p-4 rounded-xl border border-slate-700">
                    <div className="flex justify-between items-start">
                       <div>
                          <h4 className="font-bold text-white">{skill.name}</h4>
                          <p className="text-[10px] text-slate-400">{skill.description}</p>
                       </div>
                       <span className="text-[10px] font-black text-blue-400 uppercase">{skill.manaCost} Mana</span>
                    </div>
                    <div className="mt-2 text-[9px] font-black text-emerald-500 uppercase">
                       Multiplicador: x{skill.multiplier}
                    </div>
                  </div>
                ))}
             </div>
           )}

           {activeTab === 'evolve' && (
             <div className="h-full flex flex-col items-center justify-center p-8 text-center animate-in zoom-in">
                {!evolveReq ? (
                  <div className="flex flex-col items-center">
                    <div className="text-6xl mb-6">✨</div>
                    <h3 className="text-2xl font-fantasy font-black mb-2 text-yellow-500">Tier Máximo Alcançado</h3>
                    <p className="text-slate-400 text-sm">Seu pet alcançou a forma de Relíquia, o poder supremo.</p>
                  </div>
                ) : (
                  <>
                    <div className="text-6xl mb-6">🧬</div>
                    <h3 className="text-2xl font-fantasy font-black mb-2 uppercase">Ascender para {nextTier}</h3>
                    <p className="text-slate-400 text-sm mb-8 italic">Reúna fragmentos na dungeon (disponíveis a partir do nível 25) para evoluir seu pet.</p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 w-full mb-8">
                       <div className={`p-4 rounded-2xl border ${user.petFragments >= evolveReq.fragments ? 'border-green-500/50 bg-green-500/5' : 'border-slate-800 bg-slate-900/50'}`}>
                          <p className="text-[10px] font-black uppercase text-slate-500">Fragmentos</p>
                          <p className={`font-bold ${user.petFragments >= evolveReq.fragments ? 'text-green-500' : 'text-red-500'}`}>{user.petFragments} / {evolveReq.fragments}</p>
                       </div>
                       <div className={`p-4 rounded-2xl border ${user.gold >= evolveReq.gold ? 'border-green-500/50 bg-green-500/5' : 'border-slate-800 bg-slate-900/50'}`}>
                          <p className="text-[10px] font-black uppercase text-slate-500">Ouro</p>
                          <p className={`font-bold ${user.gold >= evolveReq.gold ? 'text-green-500' : 'text-red-500'}`}>{user.gold} / {evolveReq.gold}</p>
                       </div>
                       <div className={`p-4 rounded-2xl border ${user.level >= evolveReq.playerLevel ? 'border-green-500/50 bg-green-500/5' : 'border-slate-800 bg-slate-900/50'}`}>
                          <p className="text-[10px] font-black uppercase text-slate-500">Nvl Personagem</p>
                          <p className={`font-bold ${user.level >= evolveReq.playerLevel ? 'text-green-500' : 'text-red-500'}`}>{user.level} / {evolveReq.playerLevel}</p>
                       </div>
                    </div>

                    <button 
                      onClick={handleEvolution}
                      disabled={!canEvolvePet(user)}
                      className="bg-green-600 hover:bg-green-500 disabled:opacity-20 px-12 py-4 rounded-2xl font-black text-xl shadow-xl transition-all"
                    >
                      ASCENDER PET
                    </button>
                  </>
                )}
             </div>
           )}

           {activeTab === 'custom' && (
             <div className="space-y-8 animate-in fade-in">
                <div className="rpg-card p-6 rounded-2xl space-y-4">
                   <h3 className="text-xs font-black text-slate-500 uppercase">Renomear Companheiro</h3>
                   <div className="flex gap-2">
                      <input 
                        type="text" 
                        value={newName} 
                        onChange={(e) => setNewName(e.target.value)}
                        placeholder="Novo nome..."
                        className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-sm focus:border-indigo-500"
                      />
                      <button onClick={handleRename} className="bg-indigo-600 px-6 py-2 rounded-lg font-black text-xs">SALVAR</button>
                   </div>
                </div>

                <div className="rpg-card p-6 rounded-2xl space-y-4">
                   <h3 className="text-xs font-black text-slate-500 uppercase">Foto do Pet</h3>
                   <div className="flex flex-col items-center gap-4">
                      <div className="w-24 h-24 bg-slate-800 rounded-xl flex items-center justify-center border-2 border-slate-700 overflow-hidden">
                        {user.pet.image ? <img src={user.pet.image} className="w-full h-full object-cover" /> : '📸'}
                      </div>
                      <label className="bg-slate-800 hover:bg-slate-700 px-6 py-2 rounded-lg font-black text-xs cursor-pointer border border-slate-700">
                         MUDAR FOTO
                         <input type="file" accept="image/*" className="hidden" onChange={handlePetPhotoUpload} />
                      </label>
                   </div>
                </div>
             </div>
           )}
        </div>
      </div>
    </div>
  );
};

export default PetSystem;
