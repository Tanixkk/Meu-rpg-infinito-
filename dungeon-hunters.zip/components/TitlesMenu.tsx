
import React, { useState, useEffect } from 'react';
import { UserProfile, Title } from '../types';
import { checkTitleRequirements, calculateTotalPower } from '../services/gameEngine';

interface TitlesMenuProps {
  user: UserProfile;
  onUpdateUser: (updated: UserProfile) => void;
}

const TitlesMenu: React.FC<TitlesMenuProps> = ({ user, onUpdateUser }) => {
  const [titles, setTitles] = useState<Title[]>([]);
  const isAdmin = user.username === 'Tanixkk';

  useEffect(() => {
    const updatedTitles = checkTitleRequirements(user);
    setTitles(updatedTitles);
  }, [user.monsterKills, user.bossKills, user.level, user.maxFloorReached, user.characterRank, user.stats]);

  const equipTitle = (title: Title) => {
    if (!title.isUnlocked && !isAdmin) return;
    const newUser = { ...user, currentTitle: title };
    newUser.totalPower = calculateTotalPower(newUser);
    onUpdateUser(newUser);
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-4xl font-fantasy font-black glowing-text">Galeria de Títulos</h2>
          <p className="text-slate-500 uppercase text-xs font-black tracking-widest mt-1">Sua glória eternizada em palavras (32 Títulos)</p>
        </div>
        <div className="bg-slate-900 px-4 py-2 rounded-xl border border-slate-800 text-[10px] font-black uppercase text-indigo-400">
           Desbloqueados: {titles.filter(t => t.isUnlocked).length} / 32
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {titles.map(t => (
          <div key={t.id} className={`rpg-card rounded-2xl p-6 border-b-4 transition-all ${
            user.currentTitle?.id === t.id ? 'border-indigo-500 bg-indigo-500/10 scale-105' : 
            (t.isUnlocked ? 'border-green-500/50 hover:bg-slate-800/30' : 'border-slate-800 opacity-60 grayscale')
          }`}>
            <div className="flex justify-between items-start mb-2">
               <h3 className="text-xl font-fantasy font-black text-white">{t.name}</h3>
               {t.isUnlocked ? <span className="text-green-500">🔓</span> : <span className="text-slate-600">🔒</span>}
            </div>
            <p className="text-[10px] text-slate-400 italic mb-4">"{t.description}"</p>
            <div className="bg-black/30 p-3 rounded-lg mb-6">
               <p className={`text-[9px] font-black uppercase mb-2 ${t.isUnlocked ? 'text-green-500' : 'text-red-400'}`}>Requisito: {t.requirement}</p>
               <div className="grid grid-cols-2 gap-2">
                 {Object.entries(t.bonuses).map(([k, v]) => (
                   <span key={k} className="text-[10px] text-green-500 font-bold uppercase">+{v} {k}</span>
                 ))}
               </div>
            </div>
            <button 
              disabled={!t.isUnlocked && !isAdmin}
              onClick={() => equipTitle(t)}
              className={`w-full py-3 rounded-xl font-black text-xs transition-all ${
                user.currentTitle?.id === t.id ? 'bg-indigo-600 text-white' : 
                (t.isUnlocked || isAdmin ? 'bg-slate-800 hover:bg-indigo-600' : 'bg-slate-900 text-slate-700 cursor-not-allowed')
              }`}
            >
              {user.currentTitle?.id === t.id ? 'EQUIPADO' : (t.isUnlocked || isAdmin ? 'USAR TÍTULO' : 'BLOQUEADO')}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TitlesMenu;
