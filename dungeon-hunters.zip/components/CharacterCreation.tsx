
import React, { useState } from 'react';
import { CLASSES, ELEMENTS, MISSION_TEMPLATES, getBaseSkillsForElement } from '../constants';
import { ClassType, ElementType, UserProfile, CharacterRank, ElementRank } from '../types';
import { calculateExpToNext, calculateTotalPower } from '../services/gameEngine';

interface CharacterCreationProps {
  username: string;
  onComplete: (profile: UserProfile) => Promise<void>;
}

const CharacterCreation: React.FC<CharacterCreationProps> = ({ username, onComplete }) => {
  const [step, setStep] = useState(1);
  const [selectedClass, setSelectedClass] = useState<ClassType | null>(null);
  const [rolling, setRolling] = useState(false);
  const [finalizing, setFinalizing] = useState(false);
  const [rolledElement, setRolledElement] = useState<ElementType | null>(null);
  const [customAvatar, setCustomAvatar] = useState<string | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCustomAvatar(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const rollElement = () => {
    setRolling(true);
    setTimeout(() => {
      const rand = Math.random() * 100;
      let chosenElement;
      if (rand < 5) {
        const legendary = ELEMENTS.filter(e => e.rank === ElementRank.LEGENDARY);
        chosenElement = legendary[Math.floor(Math.random() * legendary.length)];
      } else if (rand < 30) {
        const rare = ELEMENTS.filter(e => e.rank === ElementRank.RARE);
        chosenElement = rare[Math.floor(Math.random() * rare.length)];
      } else {
        const common = ELEMENTS.filter(e => e.rank === ElementRank.COMMON);
        chosenElement = common[Math.floor(Math.random() * common.length)];
      }
      
      setRolledElement(chosenElement.name as ElementType);
      setRolling(false);
    }, 2000);
  };

  const handleFinish = async () => {
    if (!selectedClass || !rolledElement || finalizing) return;

    setFinalizing(true);
    const classData = CLASSES.find(c => c.name === selectedClass)!;
    
    // Corrected UserProfile initialization to include all required fields
    const initialProfile: UserProfile = {
      id: "temp",
      username,
      avatar: customAvatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`,
      level: 1,
      exp: 0,
      expToNext: calculateExpToNext(1),
      currentFloor: 1,
      maxFloorReached: 1,
      characterRank: CharacterRank.F,
      class: selectedClass,
      evolutionStage: 0,
      element: rolledElement,
      stats: {
        hp: 120 + (classData.bonuses.hp || 0),
        strength: 10 + (classData.bonuses.strength || 0),
        mana: 30 + (classData.bonuses.mana || 0),
        elementalDamage: 5 + (classData.bonuses.elementalDamage || 0),
        defense: 5 + (classData.bonuses.defense || 0),
        magicDefense: 5 + (classData.bonuses.magicDefense || 0),
        critChance: 5 + (classData.bonuses.critChance || 0),
        critDamage: 50 + (classData.bonuses.critDamage || 0)
      },
      statPoints: 10,
      gold: 100,
      skills: getBaseSkillsForElement(rolledElement),
      inventory: [],
      minerals: { coal: 0, iron: 0, silver: 0, gold: 0, mithril: 0, obsidian: 0, adamantite: 0 },
      activeMining: null,
      missions: [...MISSION_TEMPLATES],
      adventureLocations: [],
      monsterKills: 0,
      bossKills: 0,
      deaths: 0,
      totalPower: 0,
      currentTitle: null,
      ownedTitles: [],
      pet: null,
      petFragments: 0,
      buffs: [], // Fixed missing buffs property
      equipment: {
        weapon: null,
        armor: null,
        trinket: null,
        shield: null,
        helmet: null
      }
    };

    initialProfile.totalPower = calculateTotalPower(initialProfile);

    try {
      await onComplete(initialProfile);
    } catch (err) {
      console.error(err);
      alert("Houve um erro ao despertar seu caçador. Tente novamente.");
    } finally {
      setFinalizing(false);
    }
  };

  return (
    <div className="min-h-screen p-8 flex flex-col items-center justify-center bg-slate-950 overflow-y-auto">
      <div className="w-full max-w-4xl rpg-card rounded-2xl overflow-hidden shadow-2xl border-indigo-900/50">
        <div className="relative h-48 w-full bg-slate-900 overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1533154683836-84ea7a0bc310?q=80&w=2000&auto=format&fit=crop" 
            className="w-full h-full object-cover opacity-60"
            alt="Dungeon Header"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 to-transparent"></div>
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 text-center">
            <h1 className="text-5xl font-fantasy font-black glowing-text text-white uppercase">DUNGEON HUNTERS</h1>
            <p className="text-indigo-400 font-bold uppercase tracking-widest text-sm">Crie seu Caçador</p>
          </div>
        </div>

        {step === 1 ? (
          <div className="p-8">
            <div className="mb-8 flex flex-col items-center">
              <h2 className="text-xl font-fantasy text-center mb-4 uppercase">Seu Retrato</h2>
              <div className="relative group">
                <div className="w-24 h-24 rounded-full border-2 border-indigo-500 overflow-hidden bg-slate-800">
                  <img src={customAvatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`} className="w-full h-full object-cover" />
                </div>
                <label className="absolute inset-0 flex items-center justify-center bg-black/60 opacity-0 group-hover:opacity-100 cursor-pointer transition-opacity rounded-full">
                  <span className="text-[10px] font-black uppercase">UPLOAD</span>
                  <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
                </label>
              </div>
            </div>

            <h2 className="text-xl font-fantasy text-center mb-6 border-b border-slate-800 pb-2 uppercase">Escolha sua Classe Inicial</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {CLASSES.map((cls) => (
                <button
                  key={cls.name}
                  onClick={() => setSelectedClass(cls.name as ClassType)}
                  className={`p-4 rounded-xl border-2 transition-all flex flex-col items-center text-center ${
                    selectedClass === cls.name ? 'border-indigo-500 bg-indigo-500/10 scale-105' : 'border-slate-800 hover:border-slate-600'
                  }`}
                >
                  <h3 className="text-sm font-bold mb-1 uppercase">{cls.name}</h3>
                  <div className="grid grid-cols-1 gap-1 text-[8px] font-black uppercase text-slate-500">
                    {Object.entries(cls.bonuses).slice(0, 3).map(([k, v]) => (
                      <span key={k}>{k}: +{v}</span>
                    ))}
                  </div>
                </button>
              ))}
            </div>
            <div className="mt-10 flex justify-center">
              <button
                disabled={!selectedClass}
                onClick={() => setStep(2)}
                className="bg-indigo-600 px-12 py-3 rounded-full font-black uppercase hover:bg-indigo-500 disabled:opacity-50 transition-all shadow-lg shadow-indigo-900/50"
              >
                DESPERTAR ELEMENTO
              </button>
            </div>
          </div>
        ) : (
          <div className="p-12 text-center">
            <h2 className="text-3xl font-fantasy mb-2 uppercase">Despertar Elemental</h2>
            <div className="relative h-64 flex items-center justify-center mb-8">
              {rolling ? (
                <div className="flex flex-col items-center gap-4">
                  <div className="animate-spin rounded-full h-24 w-24 border-b-4 border-indigo-500 shadow-xl shadow-indigo-500/20"></div>
                  <p className="font-fantasy animate-pulse uppercase">Sincronizando com as Forças Naturais...</p>
                </div>
              ) : rolledElement ? (
                <div className="animate-in zoom-in duration-500">
                  <h3 className={`text-7xl font-black font-fantasy drop-shadow-2xl uppercase ${ELEMENTS.find(e => e.name === rolledElement)?.color}`}>
                    {rolledElement}
                  </h3>
                  <p className="mt-4 text-slate-400 italic">"{ELEMENTS.find(e => e.name === rolledElement)?.description}"</p>
                </div>
              ) : (
                <div className="text-9xl text-slate-900 font-fantasy opacity-20 select-none">?</div>
              )}
            </div>
            <div className="flex flex-col items-center gap-4">
              {!rolledElement ? (
                <button onClick={rollElement} disabled={rolling} className="bg-purple-600 px-16 py-5 rounded-full font-black text-2xl uppercase shadow-xl shadow-purple-900/50 hover:bg-purple-500 transition-all">
                  ROLETAR ELEMENTO
                </button>
              ) : (
                <button 
                  onClick={handleFinish} 
                  disabled={finalizing}
                  className="bg-green-600 px-16 py-5 rounded-full font-black text-2xl uppercase shadow-xl shadow-green-900/50 hover:bg-green-500 transition-all active:scale-95 disabled:opacity-50"
                >
                  {finalizing ? 'SINCROZINANDO...' : 'COMEÇAR JORNADA'}
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CharacterCreation;