
import React, { useState } from 'react';
import { supabase } from '../supabase';

interface AuthProps {
  onLogin: (username: string) => void;
}

const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password || (isRegistering && !username)) return;
    setLoading(true);
    setError(null);

    if (isRegistering) {
      // VERIFICAÇÃO DE SEGURANÇA: Nome único
      const { data: existingUser } = await supabase
        .from('profiles')
        .select('username')
        .eq('username', username.trim())
        .maybeSingle();

      if (existingUser) {
        setError("Esse nome já está em uso, tente outro.");
        setLoading(false);
        return;
      }

      const { data, error: signUpError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: { username: username.trim() }
        }
      });
      if (signUpError) {
        setError(signUpError.message);
        setLoading(false);
        return;
      }
      
      localStorage.setItem('zenith_temp_username', username.trim());
      onLogin(username.trim());
    } else {
      const { data, error: signInError } = await supabase.auth.signInWithPassword({
        email,
        password
      });
      if (signInError) {
        setError(signInError.message);
        setLoading(false);
        return;
      }

      const { data: profile } = await supabase
        .from('profiles')
        .select('username')
        .eq('id', data.user?.id)
        .single();

      const finalUsername = profile?.username || data.user?.user_metadata?.username || "Viajante";
      localStorage.setItem('zenith_temp_username', finalUsername);
      onLogin(finalUsername);
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-[url('https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&q=80&w=2000')] bg-cover bg-center">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm"></div>
      
      <div className="relative w-full max-w-md p-8 rpg-card rounded-2xl border-2 border-slate-700/50">
        <div className="text-center mb-8">
          <h1 className="text-5xl font-fantasy font-black glowing-text text-indigo-400 mb-2 uppercase">Dungeon Hunters</h1>
          <p className="text-slate-400 font-medium italic">A Torre Eterna aguarda por você</p>
          <p className="text-[10px] text-slate-500 font-bold uppercase mt-2">Criador: Tanixkk</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <div className="bg-red-900/50 border border-red-500 text-red-200 p-3 rounded-lg text-xs font-bold text-center animate-pulse">
              {error}
            </div>
          )}
          
          <div>
            <label className="block text-[10px] font-black uppercase text-slate-500 mb-1">E-mail Arcano</label>
            <input 
              type="email" 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={loading}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-sm"
              placeholder="seu@email.com"
              required
            />
          </div>

          {isRegistering && (
            <div>
              <label className="block text-[10px] font-black uppercase text-slate-500 mb-1">Nome de Herói (Username)</label>
              <input 
                type="text" 
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                disabled={loading}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-sm"
                placeholder="Ex: Arthas"
                required
              />
            </div>
          )}
          
          <div>
            <label className="block text-[10px] font-black uppercase text-slate-500 mb-1">Selo Arcano (Senha)</label>
            <input 
              type="password" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={loading}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-sm"
              placeholder="••••••••"
              required
            />
          </div>

          <button 
            type="submit"
            disabled={loading}
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-black py-4 rounded-xl shadow-xl shadow-indigo-900/40 transition-all active:scale-95 disabled:opacity-50 mt-4 uppercase tracking-widest text-sm"
          >
            {loading ? 'Sincronizando...' : (isRegistering ? 'Criar Nova Lenda' : 'Entrar na Torre')}
          </button>
        </form>

        <div className="mt-6 text-center">
          <button 
            onClick={() => {
              setIsRegistering(!isRegistering);
              setError(null);
            }}
            className="text-indigo-400 hover:text-indigo-300 text-[10px] font-black uppercase tracking-tighter transition-colors"
          >
            {isRegistering ? 'Já possui uma conta? Entre agora.' : 'Não tem conta? Comece sua jornada.'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Auth;
