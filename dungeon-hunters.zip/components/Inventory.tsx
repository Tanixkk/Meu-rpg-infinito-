
import React from 'react';
import { UserProfile, Equipment, ItemType } from '../types';

interface InventoryProps {
  user: UserProfile;
  onUpdateUser: (updated: UserProfile) => void;
}

const Inventory: React.FC<InventoryProps> = ({ user, onUpdateUser }) => {
  const equipItem = (item: Equipment) => {
    const newUser = { ...user };
    const slotMapping: Record<ItemType, keyof UserProfile['equipment']> = {
      'Arma': 'weapon',
      'Armadura': 'armor',
      'Amuleto': 'trinket',
      'Escudo': 'shield',
      'Elmo': 'helmet'
    };
    
    const slot = slotMapping[item.type];
    const current = newUser.equipment[slot];
    if (current) {
      newUser.inventory.push(current);
    }

    newUser.equipment[slot] = item;
    newUser.inventory = newUser.inventory.filter(i => i.id !== item.id);
    onUpdateUser(newUser);
  };

  const unequipItem = (slot: keyof UserProfile['equipment']) => {
    const newUser = { ...user };
    const item = newUser.equipment[slot];
    if (item) {
      newUser.inventory.push(item);
      newUser.equipment[slot] = null;
      onUpdateUser(newUser);
    }
  };

  const sellItem = (item: Equipment) => {
    const values: Record<string, number> = { 'Mítico': 2000, 'Lendário': 800, 'Raro': 200, 'Comum': 50 };
    const newUser = { ...user };
    newUser.gold += values[item.rarity] || 50;
    newUser.inventory = newUser.inventory.filter(i => i.id !== item.id);
    onUpdateUser(newUser);
  };

  const renderSlot = (slot: keyof UserProfile['equipment'], label: string, icon: string) => {
    const item = user.equipment[slot];
    return (
      <div className="flex flex-col items-center">
        <span className="text-[8px] text-slate-500 uppercase font-black mb-1">{label}</span>
        <div 
          onClick={() => unequipItem(slot)}
          className={`w-14 h-14 rounded-xl border-2 flex items-center justify-center cursor-pointer transition-all ${
            item ? 'border-indigo-500 bg-indigo-500/10 shadow-[0_0_10px_rgba(99,102,241,0.3)]' : 'border-slate-800 bg-slate-900 text-slate-700'
          }`}
        >
          {item ? (
            <span className="text-2xl">{item.type === 'Arma' ? '⚔️' : item.type === 'Armadura' ? '🛡️' : item.type === 'Escudo' ? '🧱' : item.type === 'Elmo' ? '🪖' : '📿'}</span>
          ) : icon}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-fantasy font-black">Inventário & Equipamento</h2>
        <div className="bg-amber-500/10 border border-amber-500/50 px-4 py-2 rounded-xl flex items-center gap-2">
          <span className="font-black text-amber-500">💰 {user.gold} GOLD</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-4 rpg-card rounded-3xl p-6 h-fit sticky top-0">
          <h3 className="text-xs font-black text-slate-500 uppercase mb-8 tracking-widest text-center">Configuração de Batalha</h3>
          <div className="flex flex-col items-center gap-8">
            <div className="flex gap-4">
              {renderSlot('helmet', 'Cabeça', '🪖')}
            </div>
            <div className="flex gap-4 items-center">
              {renderSlot('weapon', 'Mão Principal', '⚔️')}
              {renderSlot('armor', 'Torso', '🛡️')}
              {renderSlot('shield', 'Mão Secundária', '🧱')}
            </div>
            <div className="flex gap-4">
              {renderSlot('trinket', 'Amuleto', '📿')}
            </div>
          </div>
          
          <div className="mt-12 bg-black/40 rounded-2xl p-4 border border-slate-800">
             <h4 className="text-[10px] font-black text-slate-500 uppercase mb-3">Atributos Totais</h4>
             <div className="grid grid-cols-2 gap-y-2 text-[11px] font-bold">
                {Object.entries(user.stats).map(([k, v]) => (
                  <p key={k} className="flex justify-between px-2">
                    <span className="text-slate-400 capitalize">{k}</span>
                    <span className="text-indigo-400">{v}</span>
                  </p>
                ))}
             </div>
          </div>
        </div>

        <div className="lg:col-span-8 rpg-card rounded-3xl p-6 min-h-[500px]">
          <h3 className="text-xs font-black text-slate-500 uppercase mb-6 tracking-widest">Mochila ({user.inventory.length}/50)</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-4">
            {user.inventory.map(item => (
              <div 
                key={item.id} 
                className={`p-4 rounded-2xl border-2 relative group transition-all ${
                  item.rarity === 'Mítico' ? 'border-red-600 bg-red-900/5 shadow-[0_0_15px_rgba(220,38,38,0.2)]' :
                  item.rarity === 'Lendário' ? 'border-yellow-500 bg-yellow-500/5' : 
                  item.rarity === 'Raro' ? 'border-blue-500 bg-blue-500/5' : 'border-slate-800 bg-slate-900/50'
                }`}
              >
                <div className="text-3xl mb-3">
                  {item.type === 'Arma' ? '⚔️' : item.type === 'Armadura' ? '🛡️' : item.type === 'Escudo' ? '🧱' : item.type === 'Elmo' ? '🪖' : '📿'}
                </div>
                <h4 className="text-[10px] font-black truncate text-white leading-tight uppercase mb-1">{item.name}</h4>
                <div className="space-y-0.5">
                  {Object.entries(item.stats).map(([k, v]) => (
                    <p key={k} className="text-[9px] font-black text-green-500 uppercase">+{v} {k}</p>
                  ))}
                </div>

                <div className="absolute inset-0 bg-slate-950/95 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2 p-4">
                  <button 
                    onClick={() => equipItem(item)}
                    className="w-full bg-indigo-600 hover:bg-indigo-500 py-2 rounded-xl text-[10px] font-black transition-all"
                  >
                    EQUIPAR
                  </button>
                  <button 
                    onClick={() => sellItem(item)}
                    className="w-full bg-red-900/30 hover:bg-red-600 py-2 rounded-xl text-[10px] font-black text-red-200 transition-all border border-red-900/50"
                  >
                    VENDER
                  </button>
                </div>
              </div>
            ))}
            {user.inventory.length === 0 && (
              <div className="col-span-full py-32 flex flex-col items-center justify-center text-slate-600 grayscale opacity-50">
                <span className="text-6xl mb-4">🎒</span>
                <p className="italic text-sm">Nenhum tesouro encontrado ainda...</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Inventory;
