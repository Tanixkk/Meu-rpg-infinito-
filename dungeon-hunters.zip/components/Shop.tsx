
import React, { useState, useEffect } from 'react';
import { UserProfile, Equipment, Rarity, ItemType } from '../types';
import { supabase } from '../supabase';

interface ShopProps {
  user: UserProfile;
  onUpdateUser: (updated: UserProfile) => void;
}

const Shop: React.FC<ShopProps> = ({ user, onUpdateUser }) => {
  const [customItems, setCustomItems] = useState<any[]>([]);

  useEffect(() => {
    const fetchCustomItems = async () => {
      const { data } = await supabase
        .from('custom_shop')
        .select('*');
      if (data) setCustomItems(data);
    };
    fetchCustomItems();
  }, []);

  const baseItems = [
    { id: 's1', name: 'Poção de Força', price: 100, desc: 'Aumenta permanentemente 2 de Força.', action: (u: UserProfile) => { u.stats.strength += 2; } },
    { id: 's2', name: 'Cristal de Vida', price: 250, desc: 'Aumenta permanentemente 30 de HP.', action: (u: UserProfile) => { u.stats.hp += 30; } },
    { id: 's3', name: 'Mana Estelar', price: 200, desc: 'Aumenta permanentemente 15 de Mana.', action: (u: UserProfile) => { u.stats.mana += 15; } }
  ];

  const buyItem = (item: any) => {
    if (user.gold < item.price) {
      alert("Ouro insuficiente!");
      return;
    }

    const newUser = { ...user };
    newUser.gold -= item.price;

    if (item.action) {
      item.action(newUser);
    } else {
      const equip: Equipment = {
        id: Math.random().toString(36).substr(2, 9),
        name: item.name,
        type: item.type || 'Arma',
        rarity: item.rarity || 'Comum',
        stats: item.stats || {},
        levelRequired: item.levelRequired || 1,
        description: item.desc || item.description
      };
      newUser.inventory.push(equip);
    }

    onUpdateUser(newUser);
    alert(`${item.name} comprado!`);
  };

  return (
    <div className="space-y-8 animate-in fade-in">
      <div className="flex justify-between items-center">
        <div>
           <h2 className="text-3xl font-fantasy font-black">Mercado da Masmorra</h2>
           <p className="text-slate-500 text-xs font-black uppercase">Suprimentos e Relíquias Live</p>
        </div>
        <div className="bg-amber-500/10 border border-amber-500/50 px-6 py-2 rounded-xl text-amber-500 font-black">
          💰 {user.gold} GOLD
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {baseItems.map(item => (
          <div key={item.id} className="rpg-card rounded-2xl p-6 flex flex-col justify-between border-b-4 border-slate-800 hover:border-amber-500 transition-all">
            <div className="mb-6">
              <div className="w-12 h-12 bg-slate-800 rounded-lg flex items-center justify-center text-2xl mb-4">🔮</div>
              <h3 className="font-bold text-lg">{item.name}</h3>
              <p className="text-xs text-slate-500 mt-1">{item.desc}</p>
            </div>
            <button onClick={() => buyItem(item)} className="w-full bg-slate-800 hover:bg-amber-600 py-3 rounded-xl font-black text-sm">
              COMPRAR: {item.price} 💰
            </button>
          </div>
        ))}

        {customItems.map((item, idx) => (
           <div key={`custom-${idx}`} className="rpg-card rounded-2xl p-6 flex flex-col justify-between border-b-4 border-red-900/50 hover:border-red-600 transition-all bg-red-950/10">
              <div className="mb-6">
                 <div className="flex justify-between items-start mb-4">
                    <div className="w-12 h-12 bg-red-900/20 rounded-lg flex items-center justify-center text-2xl">⚔️</div>
                    <span className="text-[8px] bg-red-600 px-2 py-0.5 rounded text-white font-black">ADMIN ITEM</span>
                 </div>
                 <h3 className="font-bold text-lg text-white">{item.name}</h3>
                 <p className="text-[10px] text-red-400 font-black uppercase mb-2">Criador: {item.creator}</p>
                 <div className="mt-3 space-y-1">
                    {Object.entries(item.stats || {}).map(([k, v]) => (
                       <p key={k} className="text-[9px] font-black text-green-500 uppercase">+{v} {k}</p>
                    ))}
                 </div>
              </div>
              <button onClick={() => buyItem(item)} className="w-full bg-red-900/40 hover:bg-red-600 py-3 rounded-xl font-black text-sm border border-red-600/30">
                ADQUIRIR: {item.price} 💰
              </button>
           </div>
        ))}
      </div>
    </div>
  );
};

export default Shop;
