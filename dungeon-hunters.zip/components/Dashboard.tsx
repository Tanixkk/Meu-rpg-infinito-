
import React, { useState, useEffect } from 'react';
import { UserProfile, ClassData, CharacterRank } from '../types';
import { ELEMENTS } from '../constants';
import TowerMap from './TowerMap';
import StatsTree from './StatsTree';
import SkillTree from './SkillTree';
import Leaderboard from './Leaderboard';
import PvP from './PvP';
import Inventory from './Inventory';
import Mining from './Mining';
import Crafting from './Crafting';
import GlobalChat from './GlobalChat';
import Shop from './Shop';
import ProfileEditor from './ProfileEditor';
import ClassEvolution from './ClassEvolution';
import TitlesMenu from './TitlesMenu';
import PetSystem from './PetSystem';
import CharacterSheet from './CharacterSheet';
import StatsAndMap from './StatsAndMap';
import Adventure from './Adventure';
import { getStaticClassEvolutions, calculateTotalPower, getEvolutionStageName, getRankColor } from '../services/gameEngine';

interface DashboardProps {
  user: UserProfile;
  onUpdateUser: (updated: UserProfile) => void;
  onLogout: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ user, onUpdateUser, onLogout }) => {
  const [activeTab, setActiveTab] = useState<'tower' | 'stats' | 'skills' | 'pvp' | 'rankings' | 'inventory' | 'mining' | 'crafting' | 'missions' | 'chat' | 'shop' | 'profile' | 'titles' | 'pet' | 'map' | 'adventure'>('tower');
  const [evolutionOptions, setEvolutionOptions] = useState<ClassData[]>([]);
  const [showEvolution, setShowEvolution] = useState(false);
  const [viewingPlayerId, setViewingPlayerId] = useState<string | null>(null);

  const elementData = ELEMENTS.find(e => e.name === user.element)!;
  const pendingMissions = user.missions.filter(m => !m.isCompleted).length;
  const canPet = user.level >= 22; // Adjusted to D Rank floor

  useEffect(() => {
    const checkEvolution = () => {
      // Adjusted evolution logic to use expanded ranks
      const canEvolveToAwakened = user.evolutionStage === 0 && user.level >= 50 && ['C', 'C+', 'B', 'B+', 'A', 'A+', 'S', 'S+', 'SS', 'SS+', 'SSS', 'EX'].includes(user.characterRank);
      const canEvolveToRelic = user.evolutionStage === 1 && user.level >= 160 && ['A', 'A+', 'S', 'S+', 'SS', 'SS+', 'SSS', 'EX'].includes(user.characterRank);
      if (canEvolveToAwakened || canEvolveToRelic) {
        const options = getStaticClassEvolutions(user);
        if (options.length > 0) {
          setEvolutionOptions(options);
          setShowEvolution(true);
        }
      }
    };
    checkEvolution();
  }, [user.level, user.evolutionStage, user.class, user.characterRank]);

  const handleEvolutionSelect = (chosen: ClassData) => {
    const newUser = { ...user, class: chosen.name, evolutionStage: user.evolutionStage + 1 };
    Object.entries(chosen.bonuses).forEach(([stat, val]) => (newUser.stats as any)[stat] += val);
    newUser.totalPower = calculateTotalPower(newUser);
    onUpdateUser(newUser);
    setShowEvolution(false);
  };

  const renderContent = () => {
    if (viewingPlayerId) return <CharacterSheet playerId={viewingPlayerId} onBack={() => setViewingPlayerId(null)} />;
    switch (activeTab) {
      case 'tower': return <TowerMap user={user} onUpdateUser={onUpdateUser} />;
      case 'adventure': return <Adventure user={user} onUpdateUser={onUpdateUser} />;
      case 'stats': return <StatsTree user={user} onUpdateUser={onUpdateUser} />;
      case 'skills': return <SkillTree user={user} onUpdateUser={onUpdateUser} />;
      case 'titles': return <TitlesMenu user={user} onUpdateUser={onUpdateUser} />;
      case 'pet': return <PetSystem user={user} onUpdateUser={onUpdateUser} />;
      case 'map': return <StatsAndMap user={user} />;
      case 'pvp': return <PvP user={user} onUpdateUser={onUpdateUser} onPreviewPlayer={setViewingPlayerId} />;
      case 'rankings': return <Leaderboard user={user} onPreviewPlayer={setViewingPlayerId} />;
      case 'inventory': return <Inventory user={user} onUpdateUser={onUpdateUser} />;
      case 'mining': return <Mining user={user} onUpdateUser={onUpdateUser} />;
      case 'crafting': return <Crafting user={user} onUpdateUser={onUpdateUser} />;
      case 'shop': return <Shop user={user} onUpdateUser={onUpdateUser} />;
      case 'chat': return <GlobalChat user={user} onUpdateUser={onUpdateUser} />;
      case 'profile': return <ProfileEditor user={user} onUpdateUser={onUpdateUser} />;
      case 'missions': return (
        <div className="space-y-6">
          <h2 className="text-3xl font-fantasy font-black glowing-text uppercase tracking-widest">Diário de Missões</h2>
          {user.missions.length === 0 ? (
             <p className="text-slate-500 italic">Nenhuma missão ativa. Visite um Vilarejo no Mundo Aberto!</p>
          ) : (
            user.missions.map(m => (
              <div key={m.id} className={`rpg-card p-6 rounded-2xl border-l-4 transition-all ${m.isCompleted ? 'border-green-500 opacity-60 bg-green-500/5' : 'border-indigo-500 bg-indigo-500/5'}`}>
                <div className="flex justify-between items-start">
                  <h3 className="font-bold text-xl">{m.title}</h3>
                  {m.isCompleted && <span className="text-green-500 text-[10px] font-black uppercase">Concluída</span>}
                </div>
                <p className="text-slate-400 text-sm mb-4">{m.description}</p>
                <div className="flex items-center justify-between">
                  <div className="flex-1 mr-4">
                    <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-indigo-500" style={{ width: `${(m.current / m.target) * 100}%` }}></div>
                    </div>
                  </div>
                  <span className="text-[10px] font-black uppercase text-slate-500 whitespace-nowrap">{m.current} / {m.target}</span>
                </div>
              </div>
            ))
          )}
        </div>
      );
      default: return null;
    }
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-slate-950 overflow-hidden">
      {showEvolution && <ClassEvolution user={user} options={evolutionOptions} onSelect={handleEvolutionSelect} />}
      
      <aside className="w-full md:w-72 bg-slate-900 border-r border-slate-800 flex flex-col z-20 shadow-2xl">
        <div className="p-6 border-b border-slate-800 bg-slate-900/50 backdrop-blur-xl">
          <button onClick={() => setActiveTab('profile')} className="flex items-center gap-3 mb-4 group w-full text-left">
            <div className={`w-14 h-14 rounded-2xl overflow-hidden flex items-center justify-center bg-slate-800 border-2 group-hover:border-indigo-500 transition-all ${elementData.color.replace('text', 'border')}`}>
              <img src={user.avatar} className="w-full h-full object-cover" />
            </div>
            <div className="flex-1 overflow-hidden">
              <h3 className="font-bold text-lg leading-tight truncate text-white">{user.username}</h3>
              <p className={`text-[9px] font-black uppercase text-indigo-400 truncate`}>{user.currentTitle?.name || 'Iniciante'}</p>
              <p className="text-[8px] font-black uppercase text-slate-500">{user.class} [{getEvolutionStageName(user.evolutionStage)}]</p>
            </div>
          </button>
          <div className="space-y-2">
            <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full bg-indigo-500" style={{ width: `${(user.exp / user.expToNext) * 100}%` }}></div>
            </div>
            <div className="flex justify-between text-[10px] font-black uppercase">
              <span className="text-slate-500">Nvl {user.level} <span className={getRankColor(user.characterRank)}>[{user.characterRank}]</span></span>
              <span className="text-yellow-500">Poder: {user.totalPower}</span>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1 overflow-y-auto custom-scrollbar">
          <p className="text-[10px] font-black text-slate-600 uppercase px-3 mb-2 tracking-widest">Exploração</p>
          {[
            { id: 'tower', label: 'Torre Eterna', icon: '⚔️' },
            { id: 'adventure', label: 'Mundo Aberto', icon: '🌍' },
            { id: 'map', label: 'Mapa Dungeon', icon: '🗺️' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all ${activeTab === tab.id ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/40' : 'text-slate-400 hover:bg-slate-800'}`}
            >
              <span className="text-lg">{tab.icon}</span>
              <span className="font-bold text-[11px] uppercase tracking-tight">{tab.label}</span>
            </button>
          ))}

          <p className="text-[10px] font-black text-slate-600 uppercase px-3 mt-6 mb-2 tracking-widest">Personagem</p>
          {[
            { id: 'inventory', label: 'Mochila', icon: '🎒' },
            { id: 'pet', label: 'Pet Elemental', icon: '🐾', disabled: !canPet },
            { id: 'titles', label: 'Títulos', icon: '📜' },
            { id: 'stats', label: 'Atributos', icon: '📈' },
            { id: 'skills', label: 'Magias', icon: '🪄' },
            { id: 'missions', label: 'Missões', icon: '📋', badge: pendingMissions },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => !tab.disabled && setActiveTab(tab.id as any)}
              disabled={tab.disabled}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-all ${
                activeTab === tab.id ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/40' : 'text-slate-400 hover:bg-slate-800'
              } ${tab.disabled ? 'opacity-20 grayscale cursor-not-allowed' : ''}`}
            >
              <div className="flex items-center gap-3">
                <span className="text-lg">{tab.icon}</span>
                <span className="font-bold text-[11px] uppercase tracking-tight">{tab.label}</span>
              </div>
              {tab.badge ? <span className="bg-red-500 text-[8px] px-1.5 rounded-full font-black animate-pulse">{tab.badge}</span> : null}
            </button>
          ))}

          <p className="text-[10px] font-black text-slate-600 uppercase px-3 mt-6 mb-2 tracking-widest">Social & Rank</p>
          {[
            { id: 'pvp', label: 'Arena Local', icon: '🏟️' },
            { id: 'chat', label: 'Chat Global', icon: '💬' },
            { id: 'rankings', label: 'Hall da Fama', icon: '🏆' },
            { id: 'shop', label: 'Mercado', icon: '🛒' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all ${activeTab === tab.id ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/40' : 'text-slate-400 hover:bg-slate-800'}`}
            >
              <span className="text-lg">{tab.icon}</span>
              <span className="font-bold text-[11px] uppercase tracking-tight">{tab.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-slate-800 mt-auto">
          <button onClick={onLogout} className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-red-400 hover:bg-red-400/10 transition-all font-black text-[10px] uppercase">
             🚪 Sair da Conta
          </button>
        </div>
      </aside>

      <main className="flex-1 relative overflow-y-auto p-4 md:p-8 bg-[url('https://www.transparenttextures.com/patterns/dark-matter.png')]">
        <div className="max-w-7xl mx-auto animate-in fade-in slide-in-from-bottom-2 duration-500">
          {renderContent()}
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
