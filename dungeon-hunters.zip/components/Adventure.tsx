
import React, { useState, useEffect } from 'react';
import { UserProfile, AdventureLocation, Mission } from '../types';
import { WORLD_LOCATIONS, MISSION_POOL } from '../constants';

interface AdventureProps {
  user: UserProfile;
  onUpdateUser: (updated: UserProfile) => void;
}

const Adventure: React.FC<AdventureProps> = ({ user, onUpdateUser }) => {
  const [selectedLocation, setSelectedLocation] = useState<AdventureLocation | null>(null);
  const [availableQuests, setAvailableQuests] = useState<Mission[]>([]);

  // Gera missões aleatórias para o local baseado no que o player não tem
  useEffect(() => {
    if (selectedLocation) {
      // Pega missões do pool que não estão no diário do jogador e respeitam o nível dele
      const filtered = MISSION_POOL.filter(q => 
        !user.missions.some(um => um.id === q.id) &&
        (!q.floorRange || user.level >= q.floorRange[0] - 10)
      );
      
      // Embaralha e pega 3
      const shuffled = [...filtered].sort(() => 0.5 - Math.random());
      setAvailableQuests(shuffled.slice(0, 3));
    }
  }, [selectedLocation, user.missions]);

  const acceptQuest = (quest: Mission) => {
    if (user.missions.length >= 10) {
      alert("Seu diário de missões está cheio!");
      return;
    }
    const newUser = { ...user };
    newUser.missions = [...newUser.missions, { ...quest, isCompleted: false, current: 0 }];
    onUpdateUser(newUser);
    // Remove da lista local para feedback visual imediato
    setAvailableQuests(prev => prev.filter(q => q.id !== quest.id));
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-4xl font-fantasy font-black glowing-text uppercase tracking-tighter">Mundo Aberto</h2>
          <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest mt-1">Explore os vilarejos e aceite desafios</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 space-y-4 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
          {WORLD_LOCATIONS.map(loc => (
            <button
              key={loc.id}
              onClick={() => setSelectedLocation(loc)}
              className={`w-full text-left p-6 rounded-3xl border-2 transition-all relative overflow-hidden group ${
                selectedLocation?.id === loc.id ? 'border-indigo-500 bg-indigo-500/10' : 'border-slate-800 bg-slate-900/50 hover:border-slate-600'
              }`}
            >
              <h3 className="font-fantasy font-bold text-xl mb-1 text-white">{loc.name}</h3>
              <p className="text-[10px] text-slate-500 uppercase font-black truncate">{loc.description}</p>
              <div className="mt-2 flex items-center gap-2">
                 <span className={`text-[8px] font-black px-2 py-0.5 rounded uppercase ${loc.type === 'Reino' ? 'bg-amber-500 text-slate-950' : 'bg-slate-700 text-slate-300'}`}>
                  {loc.type}
                </span>
              </div>
            </button>
          ))}
        </div>

        <div className="lg:col-span-2">
          {selectedLocation ? (
            <div className="rpg-card rounded-[2.5rem] p-8 min-h-[500px] animate-in slide-in-from-right duration-300 relative overflow-hidden">
              <div className="relative z-10">
                <div className="mb-10 border-b border-slate-800 pb-6">
                  <h3 className="text-3xl font-fantasy font-black text-white mb-2">{selectedLocation.name}</h3>
                  <p className="text-slate-400 italic text-lg leading-relaxed">"{selectedLocation.description}"</p>
                </div>

                <div className="space-y-6">
                  <h4 className="text-xs font-black text-slate-500 uppercase tracking-widest">Quadro de Recompensas</h4>
                  
                  {availableQuests.length > 0 ? (
                    availableQuests.map(quest => (
                      <div key={quest.id} className="bg-slate-950/60 border border-slate-800 p-6 rounded-3xl hover:border-indigo-500/50 transition-all group">
                        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-1">
                               <h5 className="text-lg font-bold text-white group-hover:text-indigo-400 transition-colors">{quest.title}</h5>
                               {quest.floorRange && (
                                 <span className="text-[8px] bg-red-900/30 text-red-500 px-2 py-0.5 rounded font-black uppercase">ANDAR {quest.floorRange[0]}-{quest.floorRange[1]}</span>
                               )}
                            </div>
                            <p className="text-sm text-slate-500 mb-4">{quest.description}</p>
                            <div className="flex gap-4">
                              <div className="flex items-center gap-1.5 bg-amber-900/10 px-3 py-1.5 rounded-xl border border-amber-900/20">
                                 <span className="text-amber-500 text-xs">💰</span>
                                 <span className="text-[10px] font-black text-amber-500 uppercase">{quest.rewardGold} GOLD</span>
                              </div>
                              <div className="flex items-center gap-1.5 bg-green-900/10 px-3 py-1.5 rounded-xl border border-green-900/20">
                                 <span className="text-green-500 text-xs">✨</span>
                                 <span className="text-[10px] font-black text-green-500 uppercase">{quest.rewardExp} XP</span>
                              </div>
                            </div>
                          </div>
                          <button 
                            onClick={() => acceptQuest(quest)}
                            className="px-8 py-3 bg-indigo-600 hover:bg-indigo-500 rounded-2xl font-black text-[10px] uppercase transition-all shadow-xl shadow-indigo-900/40 active:scale-95"
                          >
                            ACEITAR
                          </button>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="py-20 flex flex-col items-center justify-center opacity-40">
                       <span className="text-4xl mb-4">📜</span>
                       <p className="text-slate-500 italic text-sm">Nenhum contrato disponível neste momento.</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="rpg-card rounded-[2.5rem] p-8 h-full flex flex-col items-center justify-center text-slate-600 border-dashed border-2 border-slate-800 group">
               <div className="w-20 h-20 rounded-full border-2 border-slate-800 flex items-center justify-center text-3xl mb-4 group-hover:scale-110 transition-transform">🌍</div>
               <p className="font-fantasy uppercase tracking-[0.2em] text-center">Viaje para um vilarejo<br/>para ver o mural de missões</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Adventure;
