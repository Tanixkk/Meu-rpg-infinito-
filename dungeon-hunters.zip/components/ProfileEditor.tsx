
import React, { useState } from 'react';
import { UserProfile } from '../types';
import { supabase } from '../supabase';

interface ProfileEditorProps {
  user: UserProfile;
  onUpdateUser: (updated: UserProfile) => void;
}

const ProfileEditor: React.FC<ProfileEditorProps> = ({ user, onUpdateUser }) => {
  const [username, setUsername] = useState(user.username);
  const [avatarSeed, setAvatarSeed] = useState(user.username);
  const [customAvatar, setCustomAvatar] = useState<string | null>(null);
  const [customBackground, setCustomBackground] = useState<string | null>(user.backgroundPhoto || null);
  const [isSaving, setIsSaving] = useState(false);
  
  const avatars = ['adventurer', 'avataaars', 'bottts', 'pixel-art', 'big-smile', 'fun-emoji'];
  const [style, setStyle] = useState(avatars[1]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, type: 'avatar' | 'background') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (type === 'avatar') setCustomAvatar(reader.result as string);
        else setCustomBackground(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const updateProfile = async () => {
    const trimmedName = username.trim();
    if (!trimmedName) {
      alert("O nome não pode ser vazio!");
      return;
    }
    
    setIsSaving(true);

    // VERIFICAÇÃO DE SEGURANÇA: Nome único
    if (trimmedName.toLowerCase() !== user.username.toLowerCase()) {
      const { data: existingUser } = await supabase
        .from('profiles')
        .select('username')
        .eq('username', trimmedName)
        .maybeSingle();

      if (existingUser) {
        alert("Esse nome já está em uso, tente outro.");
        setIsSaving(false);
        return;
      }
    }

    const newAvatar = customAvatar || (avatarSeed !== user.username ? `https://api.dicebear.com/7.x/${style}/svg?seed=${avatarSeed}` : user.avatar);
    
    try {
      const updatedUser: UserProfile = { 
        ...user, 
        username: trimmedName,
        avatar: newAvatar,
        backgroundPhoto: customBackground || undefined
      };
      
      await onUpdateUser(updatedUser);
      alert("Perfil atualizado com sucesso!");
    } catch (error) {
      console.error(error);
      alert("Erro ao salvar perfil.");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <h2 className="text-3xl font-fantasy font-black glowing-text">Configurações do Caçador</h2>
      
      <div className="rpg-card rounded-3xl p-8 space-y-10 border border-slate-800">
        <div className="flex flex-col md:flex-row gap-12 items-center">
          <div className="flex flex-col items-center">
             <div className="relative group w-48 h-48 rounded-full border-4 border-indigo-500 p-2 bg-slate-900 overflow-hidden shadow-2xl">
                <img src={customAvatar || user.avatar} className="w-full h-full object-cover rounded-full" />
                <label className="absolute inset-0 flex flex-col items-center justify-center bg-black/70 opacity-0 group-hover:opacity-100 cursor-pointer transition-opacity">
                  <span className="text-2xl">📸</span>
                  <span className="text-[10px] font-black mt-1 uppercase">Mudar Foto</span>
                  <input type="file" accept="image/*" onChange={(e) => handleFileUpload(e, 'avatar')} className="hidden" />
                </label>
             </div>
             <p className="mt-4 text-slate-500 font-bold uppercase text-xs">Retrato Atual</p>
          </div>

          <div className="flex-1 space-y-6 w-full">
             <div>
                <label className="block text-xs font-black text-slate-500 uppercase mb-2">Nome do Caçador (Visível no Ranking)</label>
                <input 
                  type="text" 
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500 font-bold"
                  placeholder="Seu nome de herói..."
                />
             </div>

             <div>
                <label className="block text-xs font-black text-slate-500 uppercase mb-2">Gerador de Avatar Alternativo (Seed)</label>
                <div className="flex gap-2">
                  <input 
                    type="text" 
                    value={avatarSeed}
                    onChange={(e) => { setAvatarSeed(e.target.value); setCustomAvatar(null); }}
                    className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-indigo-500"
                  />
                  <button onClick={() => { setAvatarSeed(user.username); setCustomAvatar(null); }} className="text-[10px] px-4 bg-slate-800 rounded-xl font-black hover:bg-slate-700 transition-colors">RESET</button>
                </div>
             </div>

             {!customAvatar && (
               <div>
                  <label className="block text-xs font-black text-slate-500 uppercase mb-2">Estilo Visual</label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                     {avatars.map(a => (
                       <button 
                        key={a}
                        onClick={() => setStyle(a)}
                        className={`px-4 py-2 rounded-lg border text-[10px] font-black uppercase transition-all ${style === a ? 'bg-indigo-600 border-indigo-500 text-white' : 'bg-slate-800 border-slate-700 text-slate-400 hover:border-slate-500'}`}
                       >
                         {a}
                       </button>
                     ))}
                  </div>
               </div>
             )}
          </div>
        </div>

        <div className="border-t border-slate-800 pt-8">
           <label className="block text-xs font-black text-slate-500 uppercase mb-4">Plano de Fundo da Ficha de Personagem</label>
           <div className="relative group w-full h-48 rounded-2xl border-2 border-dashed border-slate-700 bg-slate-900/50 overflow-hidden shadow-inner">
              {customBackground ? (
                <img src={customBackground} className="w-full h-full object-cover opacity-60" />
              ) : (
                <div className="flex items-center justify-center h-full text-slate-600 italic text-sm">Nenhum fundo personalizado (Usando padrão do sistema)</div>
              )}
              <label className="absolute inset-0 flex flex-col items-center justify-center bg-black/50 opacity-0 group-hover:opacity-100 cursor-pointer transition-opacity">
                <span className="text-3xl">🖼️</span>
                <span className="text-xs font-black mt-2 uppercase">Fazer Upload do Fundo</span>
                <input type="file" accept="image/*" onChange={(e) => handleFileUpload(e, 'background')} className="hidden" />
              </label>
           </div>
           {customBackground && (
             <button onClick={() => setCustomBackground(null)} className="mt-3 text-[10px] text-red-500 font-black uppercase hover:text-red-400 transition-colors">Remover Fundo Customizado</button>
           )}
        </div>

        <button 
          onClick={updateProfile}
          disabled={isSaving}
          className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 py-5 rounded-2xl font-black text-lg transition-all shadow-xl shadow-indigo-900/40 active:scale-95 uppercase tracking-widest"
        >
          {isSaving ? 'Sincronizando com a Torre...' : 'CONFIRMAR ALTERAÇÕES'}
        </button>
      </div>
    </div>
  );
};

export default ProfileEditor;
