
import React, { useState, useEffect } from 'react';
import { UserProfile, DamageEffect } from '../types';
import { getEffectiveStats } from '../services/gameEngine';

interface PvPProps {
  user: UserProfile;
  onUpdateUser: (updated: UserProfile) => void;
  onPreviewPlayer: (id: string) => void;
}

const PvP: React.FC<PvPProps> = ({ user, onUpdateUser, onPreviewPlayer }) => {
  const [opponents, setOpponents] = useState<UserProfile[]>([]);
  const [battleOpponent, setBattleOpponent] = useState<UserProfile | null>(null);
  const [battleLog, setBattleLog] = useState<string[]>([]);
  const [isTurn, setIsTurn] = useState(true);
  
  const stats = getEffectiveStats(user);
  const [playerHp, setPlayerHp] = useState(stats.hp);
  const [oppHp, setOppHp] = useState(0);

  useEffect(() => {
    const all: UserProfile[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith('zenith_char_') && !key.includes(user.username)) {
        try { all.push(JSON.parse(localStorage.getItem(key)!)); } catch (e) {}
      }
    }
    setOpponents(all);
  }, [user.username]);

  const startMatch = (opp: UserProfile) => {
    setBattleOpponent(opp);
    setOppHp(getEffectiveStats(opp).hp);
    setPlayerHp(stats.hp);
    setBattleLog([`Duelo iniciado contra ${opp.username}!`, `Título: ${opp.currentTitle?.name || 'Sem Título'}`]);
    setIsTurn(true);
  };

  const handleAction = (type: 'normal' | 'elemental') => {
    if (!isTurn || !battleOpponent) return;
    const oppStats = getEffectiveStats(battleOpponent);
    let dmg = type === 'normal' ? stats.strength * 4 : stats.elementalDamage * 6;
    const actualDmg = Math.max(1, Math.floor(dmg - oppStats.defense/2));
    const newOppHp = Math.max(0, oppHp - actualDmg);
    setOppHp(newOppHp);
    setBattleLog(prev => [`Você causou ${actualDmg} de dano!`, ...prev]);
    setIsTurn(false);
    if (newOppHp <= 0) { setBattleLog(prev => ["Vitória!", ...prev]); onUpdateUser({...user, gold: user.gold + 500}); setTimeout(() => setBattleOpponent(null), 3000); }
    else { setTimeout(opponentTurn, 1000); }
  };

  const opponentTurn = () => {
    if (!battleOpponent) return;
    const oppStats = getEffectiveStats(battleOpponent);
    const actualDmg = Math.max(1, Math.floor((oppStats.strength * 3) - stats.defense/2));
    const newPlayerHp = Math.max(0, playerHp - actualDmg);
    setPlayerHp(newPlayerHp);
    setBattleLog(prev => [`${battleOpponent.username} causou ${actualDmg} de dano!`, ...prev]);
    if (newPlayerHp <= 0) { setBattleLog(prev => ["Derrota...", ...prev]); setTimeout(() => setBattleOpponent(null), 3000); }
    else { setIsTurn(true); }
  };

  return (
    <div className="space-y-8">
      {!battleOpponent ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {opponents.map(opp => (
            <div key={opp.id} className="rpg-card rounded-2xl p-6 flex flex-col justify-between border-b-4 border-slate-800">
              <div className="flex items-center gap-4 mb-6">
                <img src={opp.avatar} className="w-16 h-16 rounded-full border-2 border-slate-700" />
                <div>
                  <h4 className="font-bold">{opp.username}</h4>
                  <p className="text-[10px] text-indigo-400 font-black uppercase">Poder: {opp.totalPower}</p>
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={() => startMatch(opp)} className="flex-1 bg-indigo-600 py-2 rounded-xl text-[10px] font-black">DESAFIAR</button>
                <button onClick={() => onPreviewPlayer(opp.id)} className="bg-slate-800 px-4 py-2 rounded-xl text-[10px] font-black">FICHA</button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
           <div className="rpg-card p-6 rounded-3xl">
              <img src={user.avatar} className="w-20 h-20 mx-auto rounded-full mb-4" />
              <h3 className="font-bold">{user.username}</h3>
              <p className="text-xs text-green-500">{playerHp} HP</p>
           </div>
           <div className="flex flex-col gap-4 justify-center">
              <div className="text-3xl font-fantasy text-red-500 italic animate-pulse">ARENA</div>
              <button disabled={!isTurn} onClick={() => handleAction('normal')} className="bg-slate-800 py-3 rounded-xl">ATAQUE</button>
              <button disabled={!isTurn} onClick={() => handleAction('elemental')} className="bg-indigo-600 py-3 rounded-xl">MAGIA</button>
           </div>
           <div className="rpg-card p-6 rounded-3xl">
              <img src={battleOpponent.avatar} className="w-20 h-20 mx-auto rounded-full mb-4" />
              <h3 className="font-bold">{battleOpponent.username}</h3>
              <p className="text-xs text-red-500">{oppHp} HP</p>
           </div>
        </div>
      )}
    </div>
  );
};

export default PvP;
