
import React from 'react';
import { UserProfile, Monster } from '../types';
import { generateMonster } from '../services/gameEngine';

interface StatsAndMapProps {
  user: UserProfile;
}

const StatsAndMap: React.FC<StatsAndMapProps> = ({ user }) => {
  const currentFloor = user.currentFloor;
  const nextMonster: Monster = generateMonster(currentFloor + 1);
  
  // Logic for nearest boss floors
  const nextMiniBossFloor = Math.ceil((currentFloor + 1) / 5) * 5;
  const nextBossFloor = Math.ceil((currentFloor + 1) / 10) * 10;

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Section: Statistics */}
        <div className="lg:col-span-5 space-y-6">
          <h2 className="text-3xl font-fantasy font-black glowing-text mb-6 uppercase">Relatório de Caça</h2>
          <div className="grid grid-cols-1 gap-4">
             <div className="rpg-card p-6 rounded-3xl border-l-4 border-red-500 flex items-center justify-between">
                <div>
                   <p className="text-[10px] font-black text-slate-500 uppercase">Monstros Abatidos</p>
                   <h3 className="text-3xl font-black text-white">{user.monsterKills}</h3>
                </div>
                <span className="text-4xl">💀</span>
             </div>
             <div className="rpg-card p-6 rounded-3xl border-l-4 border-yellow-500 flex items-center justify-between">
                <div>
                   <p className="text-[10px] font-black text-slate-500 uppercase">Soberanos (Bosses) Vencidos</p>
                   <h3 className="text-3xl font-black text-white">{user.bossKills}</h3>
                </div>
                <span className="text-4xl">👑</span>
             </div>
             <div className="rpg-card p-6 rounded-3xl border-l-4 border-slate-700 flex items-center justify-between">
                <div>
                   <p className="text-[10px] font-black text-slate-500 uppercase">Mortes na Escuridão</p>
                   <h3 className="text-3xl font-black text-white">{user.deaths}</h3>
                </div>
                <span className="text-4xl">⚰️</span>
             </div>
          </div>

          <div className="rpg-card p-6 rounded-3xl mt-8">
             <h3 className="text-xs font-black text-slate-500 uppercase mb-4 border-b border-slate-800 pb-2">Próxima Ameaça</h3>
             <div className="flex gap-4 items-center">
                <img src={nextMonster.image} className="w-20 h-20 rounded-xl border-2 border-slate-700 object-cover" />
                <div>
                   <p className="text-white font-bold">{nextMonster.name}</p>
                   <p className="text-[10px] font-black text-red-500 uppercase">Andar {currentFloor + 1} | {nextMonster.type}</p>
                </div>
             </div>
          </div>
        </div>

        {/* Right Section: Mini Map */}
        <div className="lg:col-span-7 rpg-card rounded-3xl p-8 bg-black/40 border border-indigo-900/30 overflow-hidden relative min-h-[600px] flex flex-col items-center">
          <div className="absolute top-0 left-0 w-full h-full pointer-events-none opacity-5" style={{ backgroundImage: 'radial-gradient(#4f46e5 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
          
          <h2 className="text-xl font-fantasy font-black mb-12 uppercase tracking-widest text-indigo-400">Mapa de Profundeza</h2>

          {/* Vertical Path representation based on the reference */}
          <div className="relative flex flex-col items-center gap-12 w-full max-w-xs">
             
             {/* Boss Indicator */}
             <div className="flex flex-col items-center opacity-40">
                <div className="w-16 h-16 border-2 border-dashed border-slate-700 rounded-2xl flex items-center justify-center text-2xl text-slate-700">
                   👑
                </div>
                <p className="text-[10px] font-black uppercase mt-2 text-slate-500">Andar {nextBossFloor} - Soberano</p>
             </div>

             <div className="h-12 w-0.5 bg-slate-800"></div>

             {/* Mini-Boss Indicator */}
             <div className="flex flex-col items-center opacity-60">
                <div className="w-12 h-12 bg-slate-900 border border-slate-700 rounded-xl flex items-center justify-center text-xl text-slate-500">
                   💀
                </div>
                <p className="text-[10px] font-black uppercase mt-2 text-slate-500">Andar {nextMiniBossFloor} - Guardião</p>
             </div>

             <div className="h-12 w-0.5 bg-indigo-500 shadow-[0_0_10px_#4f46e5]"></div>

             {/* Player Marker */}
             <div className="flex flex-col items-center relative z-10">
                <div className="w-20 h-20 rounded-full border-4 border-indigo-500 shadow-[0_0_30px_rgba(99,102,241,0.5)] overflow-hidden bg-slate-950 p-1">
                   <img src={user.avatar} className="w-full h-full rounded-full object-cover" />
                </div>
                <div className="absolute -right-24 top-1/2 -translate-y-1/2 bg-yellow-500 text-slate-950 px-3 py-1 rounded-md text-[9px] font-black uppercase whitespace-nowrap animate-pulse">
                   Você está aqui
                </div>
                <p className="text-xl font-fantasy font-black mt-4 text-white">Andar {currentFloor}</p>
                <p className="text-[10px] font-black uppercase text-indigo-400">Subindo a Torre...</p>
             </div>

             <div className="h-12 w-0.5 bg-indigo-900/50"></div>

             {/* Previous Levels fade */}
             <div className="opacity-20 flex flex-col items-center">
                <div className="w-8 h-8 rounded-full bg-slate-800"></div>
                <p className="text-[8px] font-black mt-1">Andar {currentFloor - 1}</p>
             </div>

          </div>

          <div className="mt-auto w-full p-4 bg-indigo-900/20 rounded-2xl border border-indigo-500/20 text-center">
             <p className="text-[9px] font-black text-slate-400 uppercase">Informação de Navegação</p>
             <p className="text-xs italic text-indigo-300">"Quanto mais fundo, maior a glória... e o perigo."</p>
          </div>
        </div>

      </div>
    </div>
  );
};

export default StatsAndMap;
