
import React from 'react';
import { UserProfile, Skill } from '../types';

interface SkillTreeProps {
  user: UserProfile;
  onUpdateUser: (updated: UserProfile) => void;
}

const SkillTree: React.FC<SkillTreeProps> = ({ user, onUpdateUser }) => {
  const unlockSkill = (skillId: string) => {
    const skill = user.skills.find(s => s.id === skillId);
    if (!skill || skill.isUnlocked) return;

    if (user.level < skill.minLevel) return;

    const newUser = { ...user };
    newUser.skills = newUser.skills.map(s => 
      s.id === skillId ? { ...s, isUnlocked: true } : s
    );
    onUpdateUser(newUser);
  };

  return (
    <div className="space-y-6">
      <div className="mb-8">
        <h2 className="text-3xl font-fantasy font-black">Habilidades de {user.element}</h2>
        <p className="text-slate-400">Domine sua afinidade elemental para desbloquear magias poderosas</p>
      </div>

      <div className="space-y-4">
        {user.skills.map((skill) => (
          <div 
            key={skill.id} 
            className={`rpg-card rounded-2xl p-6 transition-all ${
              skill.isUnlocked ? 'border-indigo-500/50 bg-indigo-500/5' : 'opacity-70 grayscale border-slate-800'
            }`}
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="flex gap-4 items-start">
                <div className={`w-16 h-16 rounded-xl flex items-center justify-center text-3xl shrink-0 ${
                  skill.isUnlocked ? 'bg-indigo-600 shadow-xl shadow-indigo-900/40' : 'bg-slate-800'
                }`}>
                  ✨
                </div>
                <div>
                  <h3 className="text-xl font-bold flex items-center gap-2">
                    {skill.name}
                    {!skill.isUnlocked && <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded text-slate-500 uppercase">Bloqueado</span>}
                  </h3>
                  <p className="text-slate-400 text-sm">{skill.description}</p>
                  <div className="flex gap-4 mt-2 text-xs font-bold text-slate-500 uppercase">
                    <span className="text-blue-400">Custo: {skill.manaCost} Mana</span>
                    <span className="text-purple-400">Poder: x{skill.multiplier}</span>
                  </div>
                </div>
              </div>

              <div className="shrink-0 flex flex-col items-center md:items-end gap-2">
                {!skill.isUnlocked ? (
                  <>
                    <p className="text-xs text-slate-500">Requisito: Nvl {skill.minLevel} & Rank {skill.minRank}</p>
                    <button
                      disabled={user.level < skill.minLevel}
                      onClick={() => unlockSkill(skill.id)}
                      className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 px-6 py-2 rounded-lg font-bold transition-all text-sm"
                    >
                      Desbloquear
                    </button>
                  </>
                ) : (
                  <div className="text-green-500 font-black flex items-center gap-2">
                    <span className="text-xs">HABILITADA</span>
                    <span className="text-xl">✅</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SkillTree;
