
# ⚔️ Dungeon Hunters: A Torre Eterna

Este é um jogo de RPG infinito criado para dispositivos móveis e desktop.

## 🚀 Como Hospedar

1. Suba estes arquivos para o GitHub.
2. Conecte ao Vercel.
3. Adicione a `API_KEY` do Gemini nas variáveis de ambiente.
4. Configure o banco de dados no Supabase usando o script SQL contido em `supabase.ts`.

## 🛠️ Tecnologias
- React 19
- Tailwind CSS
- Supabase (Database & Auth)
- Google Gemini API (AI)
