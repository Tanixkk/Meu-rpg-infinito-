
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://aynwxsegjzdedigembuo.supabase.co';
const supabaseAnonKey = 'sb_publishable_HrrJxZY3nnTKKyrj6OKl0w_XitxYwhQ';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

/**
 * ==============================================================================
 * 🚀 SCRIPT SQL COMPLETO PARA O SUPABASE (COPIAR E EXECUTAR NO SQL EDITOR)
 * ==============================================================================
 * 
 * -- 1. TABELA DE PERFIS DE JOGADORES
 * CREATE TABLE IF NOT EXISTS public.profiles (
 *   id uuid REFERENCES auth.users NOT NULL PRIMARY KEY,
 *   username text UNIQUE NOT NULL,
 *   avatar text,
 *   "backgroundPhoto" text,
 *   level integer DEFAULT 1,
 *   exp integer DEFAULT 0,
 *   "expToNext" integer DEFAULT 100,
 *   "currentFloor" integer DEFAULT 1,
 *   "maxFloorReached" integer DEFAULT 1,
 *   "characterRank" text DEFAULT 'F',
 *   class text,
 *   "evolutionStage" integer DEFAULT 0,
 *   element text,
 *   stats jsonb DEFAULT '{"hp": 120, "strength": 10, "mana": 30, "elementalDamage": 5, "defense": 5, "magicDefense": 5, "critChance": 5, "critDamage": 50}'::jsonb,
 *   "statPoints" integer DEFAULT 10,
 *   gold integer DEFAULT 100,
 *   skills jsonb DEFAULT '[]'::jsonb,
 *   inventory jsonb DEFAULT '[]'::jsonb,
 *   minerals jsonb DEFAULT '{"coal": 0, "iron": 0, "silver": 0, "gold": 0, "mithril": 0, "obsidian": 0, "adamantite": 0}'::jsonb,
 *   "activeMining" jsonb DEFAULT NULL,
 *   missions jsonb DEFAULT '[]'::jsonb,
 *   "monsterKills" integer DEFAULT 0,
 *   "bossKills" integer DEFAULT 0,
 *   deaths integer DEFAULT 0,
 *   "totalPower" integer DEFAULT 0,
 *   "currentTitle" jsonb DEFAULT NULL,
 *   "ownedTitles" jsonb DEFAULT '[]'::jsonb,
 *   pet jsonb DEFAULT NULL,
 *   "petFragments" integer DEFAULT 0,
 *   buffs jsonb DEFAULT '[]'::jsonb,
 *   equipment jsonb DEFAULT '{"weapon": null, "armor": null, "trinket": null, "shield": null, "helmet": null}'::jsonb,
 *   updated_at timestamp with time zone DEFAULT now()
 * );
 * 
 * -- 2. TABELA DE MENSAGENS DO CHAT
 * CREATE TABLE IF NOT EXISTS public.chat_messages (
 *   id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 *   sender text NOT NULL,
 *   content text NOT NULL,
 *   timestamp bigint NOT NULL,
 *   "isAdmin" boolean DEFAULT false,
 *   channel text DEFAULT 'global'
 * );
 * 
 * -- 3. TABELA DE ATIVOS DO ADMINISTRADOR (CATÁLOGO)
 * CREATE TABLE IF NOT EXISTS public.created_assets (
 *   id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 *   name text UNIQUE NOT NULL,
 *   type text NOT NULL, -- 'item' ou 'magia'
 *   stats jsonb,
 *   creator text,
 *   cost integer DEFAULT 0,
 *   created_at timestamp with time zone DEFAULT now()
 * );
 * 
 * -- 4. TABELA DO MERCADO (ITENS À VENDA)
 * CREATE TABLE IF NOT EXISTS public.custom_shop (
 *   id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 *   name text UNIQUE NOT NULL,
 *   price integer NOT NULL,
 *   creator text,
 *   asset_ref uuid REFERENCES public.created_assets(id) ON DELETE CASCADE,
 *   created_at timestamp with time zone DEFAULT now()
 * );
 * 
 * -- 5. HABILITAR SEGURANÇA POR LINHA (RLS)
 * ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
 * ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
 * ALTER TABLE public.created_assets ENABLE ROW LEVEL SECURITY;
 * ALTER TABLE public.custom_shop ENABLE ROW LEVEL SECURITY;
 * 
 * -- 6. POLÍTICAS DE ACESSO (RLS)
 * 
 * -- Profiles: Todos podem ver (para rankings), mas só o dono pode atualizar ou inserir
 * DROP POLICY IF EXISTS "Public profiles are viewable by everyone" ON public.profiles;
 * CREATE POLICY "Public profiles are viewable by everyone" ON public.profiles FOR SELECT USING (true);
 * 
 * DROP POLICY IF EXISTS "Users can update their own profile" ON public.profiles;
 * CREATE POLICY "Users can update their own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);
 * 
 * DROP POLICY IF EXISTS "Users can insert their own profile" ON public.profiles;
 * CREATE POLICY "Users can insert their own profile" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);
 * 
 * -- Chat: Todos podem ler, apenas usuários autenticados podem enviar mensagens
 * DROP POLICY IF EXISTS "Everyone can view chat messages" ON public.chat_messages;
 * CREATE POLICY "Everyone can view chat messages" ON public.chat_messages FOR SELECT USING (true);
 * 
 * DROP POLICY IF EXISTS "Authenticated users can send messages" ON public.chat_messages;
 * CREATE POLICY "Authenticated users can send messages" ON public.chat_messages FOR INSERT WITH CHECK (auth.role() = 'authenticated');
 * 
 * -- Created Assets & Shop: Leitura pública, Escrita permitida para ADM (simulado via Frontend no MVP)
 * DROP POLICY IF EXISTS "Public can view assets" ON public.created_assets;
 * CREATE POLICY "Public can view assets" ON public.created_assets FOR SELECT USING (true);
 * 
 * DROP POLICY IF EXISTS "Admin access for assets" ON public.created_assets;
 * CREATE POLICY "Admin access for assets" ON public.created_assets FOR ALL USING (true);
 * 
 * DROP POLICY IF EXISTS "Public can view shop" ON public.custom_shop;
 * CREATE POLICY "Public can view shop" ON public.custom_shop FOR SELECT USING (true);
 * 
 * DROP POLICY IF EXISTS "Admin access for shop" ON public.custom_shop;
 * CREATE POLICY "Admin access for shop" ON public.custom_shop FOR ALL USING (true);
 * 
 * -- 7. HABILITAR PUBLICAÇÃO EM TEMPO REAL (REALTIME)
 * -- Certifique-se de que a publicação 'supabase_realtime' existe
 * DO $$ 
 * BEGIN
 *   IF NOT EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime') THEN
 *     CREATE PUBLICATION supabase_realtime;
 *   END IF;
 * END $$;
 * 
 * ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_messages;
 * ALTER PUBLICATION supabase_realtime ADD TABLE public.profiles;
 * ALTER PUBLICATION supabase_realtime ADD TABLE public.created_assets;
 * ALTER PUBLICATION supabase_realtime ADD TABLE public.custom_shop;
 */
